# CV Marker Pro v3.0 — Complete CV Builder & Template Portal

## Features
- **CV Builder**: Interactive drag-and-drop CV builder with 5+ templates and live preview
- **Template Download Portal**: Browse, search, filter, and download professional templates
- **Template Categories**: CV, Resume, Cover Letter, Business Card, Portfolio, Flyer, Invoice
- **User Dashboard**: Download history, favorites, profile management
- **Admin Panel**: Full CRUD for templates, categories, users, download logs, and analytics
- **AI CV Scoring**: Automated CV scoring and feedback
- **Job Applications**: Apply to jobs, track status
- **Toast Notifications**: Beautiful toast notifications for all actions
- **Responsive Design**: Bootstrap 5, mobile-first, dark theme
- **Secure**: PDO prepared statements, bcrypt passwords, CSRF protection, XSS prevention

## Installation
1. Create database `cv_marker_db` in MySQL
2. Import `sql/cv_marker_db.sql`
3. Edit `includes/config.php` with your DB credentials
4. Place in your web server (XAMPP/htdocs or similar)
5. Access: `http://localhost/cv_marker_final/`

## Default Admin Login
- Email: admin@cvmarker.com
- Any email works for admin (demo mode)

## File Structure
```
cv_marker_final/
├── index.php                 # Homepage with template showcase
├── login.php                 # Login page (admin/candidate)
├── templates_browse.php      # Template library (browse, filter, search)
├── template_detail.php       # Template detail page
├── download.php              # Secure template download handler
├── about.php                 # About page
├── contact.php               # Contact page
├── ajax/
│   └── toggle_favorite.php   # AJAX favorite toggle
├── admin/
│   ├── dashboard.php         # Admin dashboard
│   ├── templates_manage.php  # Template CRUD management
│   ├── categories.php        # Category management
│   ├── download_logs.php     # Download history logs
│   ├── jobs.php, candidates.php, etc.
├── candidate/
│   ├── dashboard.php         # User dashboard
│   ├── cv_builder.php        # CV builder
│   ├── downloads.php         # Download history
│   ├── favorites.php         # Saved templates
│   ├── profile.php, jobs.php, etc.
├── includes/
│   ├── config.php            # Database & app config
│   ├── common.css            # Shared styles
│   ├── common.js             # Toaster & shared JS
│   ├── assets.php            # CDN links
│   └── toaster.php           # Flash message handler
├── sql/
│   └── cv_marker_db.sql      # Complete database schema
├── templates/                # CV builder HTML templates
├── uploads/
│   ├── templates/            # Uploaded template files
│   ├── previews/             # Template preview images
│   └── cvs/                  # User CV uploads
└── .htaccess
```

## New in v3.0
- Template Download Portal with categories, search, pagination
- Favorite templates system
- Download history tracking
- Admin template manager with file upload
- Admin download logs viewer
- Category management
- About & Contact pages
- Updated homepage with template showcase
- Enhanced sidebar navigation
