<?php
require_once dirname(__DIR__) . '/includes/config.php';
header('Content-Type: application/json');
if (!isset($_SESSION['candidate_id'])) { echo json_encode(['success'=>false,'message'=>'Login required']); exit; }
$tid = intval($_POST['template_id'] ?? 0);
if (!$tid) { echo json_encode(['success'=>false,'message'=>'Invalid template']); exit; }
$db = getDB();
$check = $db->prepare("SELECT COUNT(*) FROM favorites WHERE user_id=? AND template_id=?");
$check->execute([$_SESSION['candidate_id'], $tid]);
if ($check->fetchColumn() > 0) {
    $db->prepare("DELETE FROM favorites WHERE user_id=? AND template_id=?")->execute([$_SESSION['candidate_id'], $tid]);
    echo json_encode(['success'=>true,'is_fav'=>false,'message'=>'Removed from favorites']);
} else {
    $db->prepare("INSERT INTO favorites (user_id, template_id) VALUES (?, ?)")->execute([$_SESSION['candidate_id'], $tid]);
    echo json_encode(['success'=>true,'is_fav'=>true,'message'=>'Added to favorites']);
}
