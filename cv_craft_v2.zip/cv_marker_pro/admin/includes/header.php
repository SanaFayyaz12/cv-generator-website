<?php
require_once dirname(dirname(__DIR__)) . '/includes/config.php';
requireAdmin();
$db = getDB();
try {
    $adminStmt = $db->prepare("SELECT * FROM admin_users WHERE id=?");
    $adminStmt->execute([$_SESSION['admin_id']]);
    $currentAdmin = $adminStmt->fetch();
    if (!$currentAdmin) {
        $currentAdmin = ['full_name'=>'Administrator','role'=>'super_admin','email'=>'admin@cvmarker.com'];
    }
    $totalCandidates = $db->query("SELECT COUNT(*) FROM candidates")->fetchColumn();
    $totalCvs = $db->query("SELECT COUNT(*) FROM cvs")->fetchColumn();
    $totalTemplates = $db->query("SELECT COUNT(*) FROM cv_templates")->fetchColumn();
    $totalDownloads = $db->query("SELECT COUNT(*) FROM download_history")->fetchColumn();
} catch(Exception $e) {
    $currentAdmin = ['full_name'=>'Administrator','role'=>'super_admin','email'=>'admin@cvmarker.com'];
    $totalCandidates = $totalCvs = $totalTemplates = $totalDownloads = 0;
}
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?? 'Dashboard' ?> — CV Craft Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Sora:wght@600;700;800&display=swap" rel="stylesheet">
<link href="<?= SITE_URL ?>/includes/common.css" rel="stylesheet">
<style>
body{font-family:'Inter',sans-serif;background:#f0f2f5;color:#1e293b;margin:0;}
.sidebar{background:#1e293b;box-shadow:4px 0 20px rgba(0,0,0,0.15);}
.sidebar-logo .logo-box{background:linear-gradient(135deg,#6366f1,#4f46e5);}
.sidebar-nav li a{color:#94a3b8;border-radius:10px;margin:2px 8px;padding:0.65rem 1rem;}
.sidebar-nav li a:hover{background:rgba(255,255,255,0.07);color:#f1f5f9;}
.sidebar-nav li a.active{background:rgba(99,102,241,0.18);color:#a5b4fc;font-weight:600;}
.sidebar-section{color:#475569;font-size:0.7rem;font-weight:700;letter-spacing:0.1em;padding:0.8rem 1.2rem 0.3rem;text-transform:uppercase;}
.topbar{background:#fff;border-bottom:1px solid #e2e8f0;box-shadow:0 1px 4px rgba(0,0,0,0.06);}
.topbar-title{color:#1e293b;font-weight:600;}
.main-wrap{background:#f0f2f5;}

/* Boxed Layout Cards */
.content{padding:1.5rem;}
.stat-card{background:#fff;border-radius:16px;padding:1.4rem 1.6rem;display:flex;align-items:center;gap:1.2rem;box-shadow:0 2px 12px rgba(0,0,0,0.06);border:1px solid #e8ecf0;transition:all 0.2s;}
.stat-card:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(0,0,0,0.1);}
.stat-card .icon{width:52px;height:52px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.stat-card .num{font-size:1.9rem;font-weight:800;color:#1e293b;line-height:1;font-family:'Sora',sans-serif;}
.stat-card .label{font-size:0.8rem;color:#64748b;margin-top:0.2rem;font-weight:500;}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem;margin-bottom:1.5rem;}
.card{background:#fff;border-radius:16px;border:1px solid #e8ecf0;box-shadow:0 2px 12px rgba(0,0,0,0.06);overflow:hidden;margin-bottom:1.2rem;}
.card-header{background:transparent;border-bottom:1px solid #f1f5f9;padding:1rem 1.4rem;display:flex;align-items:center;justify-content:space-between;}
.card-title{font-weight:700;font-size:0.95rem;color:#1e293b;display:flex;align-items:center;gap:0.5rem;}
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;}
th{background:#f8fafc;color:#64748b;font-size:0.78rem;font-weight:700;text-transform:uppercase;letter-spacing:0.05em;padding:0.75rem 1rem;}
td{padding:0.85rem 1rem;border-bottom:1px solid #f1f5f9;font-size:0.875rem;color:#334155;vertical-align:middle;}
tr:hover td{background:#fafbff;}
tr:last-child td{border-bottom:none;}
.btn-sm{padding:0.3rem 0.75rem;font-size:0.78rem;border-radius:7px;font-weight:600;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:0.3rem;}
.btn-primary{background:linear-gradient(135deg,#6366f1,#4f46e5);color:#fff;}
.btn-primary:hover{box-shadow:0 4px 12px rgba(99,102,241,0.4);}
.btn-secondary{background:#f1f5f9;color:#64748b;border:1px solid #e2e8f0;}
.btn-info{background:rgba(14,165,233,0.1);color:#0ea5e9;border:1px solid rgba(14,165,233,0.2);}
.btn-success{background:rgba(16,185,129,0.1);color:#10b981;border:1px solid rgba(16,185,129,0.2);}
.btn-danger{background:rgba(239,68,68,0.1);color:#ef4444;border:1px solid rgba(239,68,68,0.2);}
.badge{padding:0.25rem 0.6rem;border-radius:20px;font-size:0.72rem;font-weight:600;}
.row{display:grid;gap:1.2rem;}
.col-8{grid-column:span 8;}
.col-6{grid-column:span 6;}
.col-4{grid-column:span 4;}
.row{grid-template-columns:repeat(12,1fr);}
.topbar{display:flex;align-items:center;justify-content:space-between;padding:0.75rem 1.5rem;}
.form-group{margin-bottom:1rem;}
.form-group label{display:block;font-size:0.8rem;font-weight:600;color:#374151;margin-bottom:0.4rem;}
.form-control,.form-select{width:100%;padding:0.6rem 0.85rem;background:#fff;border:1px solid #e2e8f0;border-radius:9px;font-size:0.875rem;color:#1e293b;outline:none;transition:border-color 0.2s;}
.form-control:focus,.form-select:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,0.12);}
.modal-content{background:#fff;border-radius:16px;border:1px solid #e2e8f0;}
.modal-header{border-color:#f1f5f9;background:#f8fafc;border-radius:16px 16px 0 0;}
.modal-footer{border-color:#f1f5f9;}
.sidebar-user{padding:1rem 1.2rem;border-top:1px solid rgba(255,255,255,0.06);margin-top:auto;display:flex;align-items:center;gap:0.8rem;}
.avatar-circle{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.9rem;font-weight:700;color:#fff;flex-shrink:0;}
</style>
</head>
<body>
<div id="toaster-container"></div>
<div class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-box"><i class="fas fa-file-alt" style="color:#fff"></i></div>
    <div><h2 style="color:#f1f5f9">CV Craft</h2><small style="color:#64748b">Admin Panel</small></div>
  </div>
  <div class="sidebar-section">Overview</div>
  <ul class="sidebar-nav">
    <li><a href="<?= ADMIN_URL ?>/dashboard.php" class="<?= $currentPage==='dashboard.php'?'active':'' ?>"><i class="fas fa-th-large"></i> Dashboard</a></li>
  </ul>
  <div class="sidebar-section">Manage</div>
  <ul class="sidebar-nav">
    <li><a href="<?= ADMIN_URL ?>/candidates.php" class="<?= $currentPage==='candidates.php'?'active':'' ?>"><i class="fas fa-users"></i> Candidates</a></li>
    <li><a href="<?= ADMIN_URL ?>/templates_manage.php" class="<?= $currentPage==='templates_manage.php'?'active':'' ?>"><i class="fas fa-layer-group"></i> Templates</a></li>
    <li><a href="<?= ADMIN_URL ?>/categories.php" class="<?= $currentPage==='categories.php'?'active':'' ?>"><i class="fas fa-tags"></i> Categories</a></li>
    <li><a href="<?= ADMIN_URL ?>/download_logs.php" class="<?= $currentPage==='download_logs.php'?'active':'' ?>"><i class="fas fa-download"></i> Download Logs</a></li>
    <li><a href="<?= ADMIN_URL ?>/admins.php" class="<?= $currentPage==='admins.php'?'active':'' ?>"><i class="fas fa-user-shield"></i> Admin Users</a></li>
  </ul>
  <div class="sidebar-section">System</div>
  <ul class="sidebar-nav">
    <li><a href="<?= ADMIN_URL ?>/settings.php" class="<?= $currentPage==='settings.php'?'active':'' ?>"><i class="fas fa-cog"></i> Settings</a></li>
    <li><a href="<?= ADMIN_URL ?>/reports.php" class="<?= $currentPage==='reports.php'?'active':'' ?>"><i class="fas fa-chart-bar"></i> Reports</a></li>
    <li><a href="<?= ADMIN_URL ?>/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  </ul>
  <div class="sidebar-user">
    <div class="avatar-circle" style="background:linear-gradient(135deg,#6366f1,#4f46e5)">
      <?= strtoupper(substr($currentAdmin['full_name']??'A',0,1)) ?>
    </div>
    <div style="flex:1;min-width:0">
      <div style="font-size:0.85rem;font-weight:600;color:#f1f5f9;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($currentAdmin['full_name']??'Admin') ?></div>
      <div style="font-size:0.72rem;color:#64748b"><?= ucfirst(str_replace('_',' ',$currentAdmin['role']??'admin')) ?></div>
    </div>
  </div>
</div>

<div class="main-wrap">
<div class="topbar">
  <div class="d-flex align-items-center gap-3">
    <button id="sidebarToggle" class="d-lg-none btn btn-sm" style="background:#f1f5f9;border:1px solid #e2e8f0;color:#64748b"><i class="fas fa-bars"></i></button>
    <span class="topbar-title"><i class="fas fa-circle" style="font-size:0.5rem;color:#10b981;margin-right:0.4rem"></i><?= $pageTitle ?? 'Dashboard' ?></span>
  </div>
  <div class="d-flex align-items-center gap-2">
    <span style="font-size:0.8rem;color:#64748b">Welcome, <strong style="color:#1e293b"><?= htmlspecialchars($currentAdmin['full_name']??'Admin') ?></strong></span>
    <a href="<?= ADMIN_URL ?>/logout.php" class="btn btn-sm" style="background:#fff;border:1px solid #e2e8f0;color:#ef4444;"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</div>
<?php
$flash = getFlash();
if ($flash): ?>
<script>document.addEventListener('DOMContentLoaded',()=>showToast('<?= addslashes($flash['message']) ?>','<?= $flash['type'] ?>'));</script>
<?php endif; ?>
<style>
/* Compat styles for older admin pages */
.page-title{font-weight:700;font-size:1rem;color:#1e293b;display:flex;align-items:center;gap:0.5rem;}
.topbar-actions{display:flex;gap:0.5rem;align-items:center;}
.topbar-btn{padding:0.4rem 0.9rem;border-radius:8px;font-size:0.82rem;font-weight:600;border:1px solid #e2e8f0;background:#f8fafc;color:#374151;text-decoration:none;display:inline-flex;align-items:center;gap:0.3rem;cursor:pointer;transition:all 0.2s;}
.topbar-btn.primary{background:linear-gradient(135deg,#6366f1,#4f46e5);color:#fff;border-color:#6366f1;}
.topbar-btn:hover{box-shadow:0 2px 8px rgba(0,0,0,0.1);}
.table-wrap{overflow-x:auto;padding:0 0.5rem 0.5rem;}
.table>:not(caption)>*>*{background:#fff;color:#334155;border-color:#f1f5f9;}
.badge-pending{background:#fef3c7;color:#d97706;}
.badge-active{background:#d1fae5;color:#059669;}
.badge-inactive{background:#fee2e2;color:#dc2626;}
.content-area{padding:0;}
/* Fix var(--primary) references */
:root{--primary:#6366f1;--success:#10b981;--warning:#f59e0b;--danger:#ef4444;--info:#0ea5e9;--accent:#6366f1;--text-muted:#64748b;--text-light:#f1f5f9;--dark-card:#fff;--dark-border:#e2e8f0;--radius:12px;--shadow:0 4px 16px rgba(0,0,0,0.08);}
</style>
