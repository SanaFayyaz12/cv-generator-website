</div><!-- end main-wrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="<?= SITE_URL ?>/includes/common.js"></script>
<script>
// Sidebar toggle for mobile
var tog = document.getElementById('sidebarToggle');
if(tog){tog.addEventListener('click',function(){document.getElementById('sidebar').classList.toggle('open');});}
// Bootstrap tooltips
var tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
tooltips.forEach(function(t){new bootstrap.Tooltip(t);});
</script>
</body></html>
