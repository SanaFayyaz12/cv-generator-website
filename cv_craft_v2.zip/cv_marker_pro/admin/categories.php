<?php
$pageTitle = 'Categories';
require_once 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? '';
    if ($act === 'add') {
        $name = sanitize($_POST['name'] ?? '');
        $slug = strtolower(preg_replace('/[^a-z0-9]+/', '-', strtolower($name)));
        $icon = sanitize($_POST['icon'] ?? 'fa-file-alt');
        $desc = sanitize($_POST['description'] ?? '');
        $db->prepare("INSERT INTO template_categories (name,slug,icon,description) VALUES (?,?,?,?)")->execute([$name,$slug,$icon,$desc]);
        setFlash('success', 'Category added!');
    } elseif ($act === 'delete') {
        $db->prepare("DELETE FROM template_categories WHERE id=?")->execute([intval($_POST['delete_id'])]);
        setFlash('success', 'Category deleted.');
    }
    header('Location: categories.php'); exit;
}

$cats = $db->query("SELECT c.*, (SELECT COUNT(*) FROM downloadable_templates WHERE category_id=c.id) as tpl_count FROM template_categories c ORDER BY sort_order")->fetchAll();
?>
<div class="topbar">
    <div class="page-title"><i class="fas fa-tags" style="color:#f59e0b"></i> Categories</div>
    <div class="topbar-actions">
        <button class="topbar-btn primary" onclick="document.getElementById('catModal').style.display='flex'">
            <i class="fas fa-plus"></i> Add Category
        </button>
    </div>
</div>

<div class="content">
    <?php if(empty($cats)): ?>
    <div class="card" style="text-align:center;padding:3rem">
        <i class="fas fa-tags" style="font-size:3rem;opacity:0.2;margin-bottom:1rem;display:block"></i>
        <p style="color:var(--text-muted)">No categories yet. Add your first one!</p>
    </div>
    <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:1.2rem">
        <?php foreach($cats as $c): ?>
        <div style="background:#fff;border:1px solid #e8ecf0;border-radius:16px;padding:1.6rem 1.4rem;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.06);transition:all 0.2s;position:relative">
            <div style="width:60px;height:60px;border-radius:16px;background:linear-gradient(135deg,rgba(99,102,241,0.12),rgba(139,92,246,0.12));display:flex;align-items:center;justify-content:center;margin:0 auto 1rem">
                <i class="fas <?= htmlspecialchars($c['icon']) ?>" style="font-size:1.5rem;color:#6366f1"></i>
            </div>
            <h5 style="font-family:'Sora',sans-serif;font-weight:700;color:#1e293b;margin-bottom:0.3rem;font-size:1rem"><?= htmlspecialchars($c['name']) ?></h5>
            <?php if($c['description']): ?>
            <p style="font-size:0.78rem;color:#94a3b8;margin-bottom:0.6rem;line-height:1.5"><?= htmlspecialchars($c['description']) ?></p>
            <?php endif; ?>
            <div style="display:inline-flex;align-items:center;gap:0.35rem;background:#f1f5f9;border-radius:20px;padding:0.25rem 0.75rem;margin-bottom:1rem">
                <i class="fas fa-layer-group" style="font-size:0.7rem;color:#6366f1"></i>
                <span style="font-size:0.78rem;font-weight:600;color:#475569"><?= $c['tpl_count'] ?> template<?= $c['tpl_count'] != 1 ? 's' : '' ?></span>
            </div>
            <div style="border-top:1px solid #f1f5f9;padding-top:0.85rem">
                <form method="POST" onsubmit="return confirm('Delete this category?')">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="delete_id" value="<?= $c['id'] ?>">
                    <button type="submit" style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.18);color:#ef4444;padding:0.35rem 0.85rem;border-radius:8px;font-size:0.78rem;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:0.3rem">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<!-- Add Modal -->
<div id="catModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center">
    <div style="background:#fff;border-radius:16px;width:100%;max-width:460px;margin:1rem;box-shadow:0 20px 60px rgba(0,0,0,0.2)">
        <div style="padding:1.25rem 1.5rem;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between">
            <h5 style="font-family:'Sora',sans-serif;font-weight:700;color:#1e293b;margin:0;font-size:1rem">Add Category</h5>
            <button onclick="document.getElementById('catModal').style.display='none'" style="background:none;border:none;color:#94a3b8;font-size:1.2rem;cursor:pointer;padding:0.2rem">✕</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="add">
            <div style="padding:1.5rem">
                <div style="margin-bottom:1rem">
                    <label style="display:block;font-size:0.8rem;font-weight:600;color:#374151;margin-bottom:0.4rem">Name *</label>
                    <input type="text" name="name" class="form-control" required placeholder="e.g. CV / Resume">
                </div>
                <div style="margin-bottom:1rem">
                    <label style="display:block;font-size:0.8rem;font-weight:600;color:#374151;margin-bottom:0.4rem">Font Awesome Icon</label>
                    <input type="text" name="icon" class="form-control" value="fa-file-alt" placeholder="fa-file-alt">
                    <small style="color:#94a3b8;font-size:0.75rem;display:block;margin-top:0.3rem">e.g. fa-file-alt, fa-envelope, fa-id-card</small>
                </div>
                <div>
                    <label style="display:block;font-size:0.8rem;font-weight:600;color:#374151;margin-bottom:0.4rem">Description</label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Brief description..."></textarea>
                </div>
            </div>
            <div style="padding:1rem 1.5rem;border-top:1px solid #f1f5f9;display:flex;gap:0.5rem;justify-content:flex-end">
                <button type="button" onclick="document.getElementById('catModal').style.display='none'" class="btn btn-secondary btn-sm">Cancel</button>
                <button type="submit" style="background:linear-gradient(135deg,#6366f1,#4f46e5);color:#fff;border:none;padding:0.4rem 1.1rem;border-radius:8px;font-weight:600;font-size:0.85rem;cursor:pointer">Add Category</button>
            </div>
        </form>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
