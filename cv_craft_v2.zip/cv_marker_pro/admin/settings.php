<?php
$pageTitle = 'System Settings';
require_once 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'setting_') === 0) {
            $settingKey = substr($key, 8);
            try {
                $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value=?");
                $stmt->execute([sanitize($settingKey), sanitize($value), sanitize($value)]);
            } catch(Exception $e) {}
        }
    }
    setFlash('success', 'Settings saved successfully!');
    header('Location: settings.php');
    exit;
}

try {
    $settings = $db->query("SELECT * FROM system_settings")->fetchAll(PDO::FETCH_UNIQUE);
} catch(Exception $e) { $settings = []; }
?>
<div class="content">
  <div style="margin-bottom:1.5rem">
    <h1 style="font-family:'Sora',sans-serif;font-size:1.4rem;font-weight:800;color:#1e293b;margin:0"><i class="fas fa-cog" style="color:#6366f1"></i> System Settings</h1>
    <p style="color:#64748b;font-size:0.85rem;margin:0.3rem 0 0">Configure your CV Craft application settings.</p>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.2rem">
    <!-- General Settings -->
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fas fa-sliders-h" style="color:#6366f1"></i> General Settings</div></div>
      <div style="padding:1.4rem">
        <form method="POST">
          <div class="form-group">
            <label>Site Name</label>
            <input type="text" name="setting_site_name" class="form-control" value="<?= htmlspecialchars($settings['site_name']['setting_value'] ?? 'CV Craft') ?>">
          </div>
          <div class="form-group">
            <label>Site Tagline</label>
            <input type="text" name="setting_site_tagline" class="form-control" value="<?= htmlspecialchars($settings['site_tagline']['setting_value'] ?? 'Build Your Professional Resume') ?>">
          </div>
          <div class="form-group">
            <label>Contact Email</label>
            <input type="email" name="setting_contact_email" class="form-control" value="<?= htmlspecialchars($settings['contact_email']['setting_value'] ?? 'admin@cvmarker.com') ?>">
          </div>
          <div class="form-group">
            <label>Allow Registrations</label>
            <select name="setting_allow_registration" class="form-select">
              <option value="1" <?= ($settings['allow_registration']['setting_value'] ?? '1')=='1'?'selected':'' ?>>Yes - Allow new registrations</option>
              <option value="0" <?= ($settings['allow_registration']['setting_value'] ?? '1')=='0'?'selected':'' ?>>No - Registration closed</option>
            </select>
          </div>
          <button type="submit" class="btn-sm btn-primary" style="padding:0.6rem 1.4rem"><i class="fas fa-save"></i> Save Settings</button>
        </form>
      </div>
    </div>

    <!-- Template Settings -->
    <div class="card">
      <div class="card-header"><div class="card-title"><i class="fas fa-layer-group" style="color:#10b981"></i> Template & CV Settings</div></div>
      <div style="padding:1.4rem">
        <form method="POST">
          <div class="form-group">
            <label>Max CVs Per User</label>
            <input type="number" name="setting_max_cvs_per_user" class="form-control" value="<?= htmlspecialchars($settings['max_cvs_per_user']['setting_value'] ?? '10') ?>" min="1" max="50">
          </div>
          <div class="form-group">
            <label>Default Template</label>
            <select name="setting_default_template" class="form-select">
              <option value="clean" <?= ($settings['default_template']['setting_value'] ?? 'clean')=='clean'?'selected':'' ?>>Clean</option>
              <option value="professional" <?= ($settings['default_template']['setting_value'] ?? 'clean')=='professional'?'selected':'' ?>>Professional</option>
              <option value="modern" <?= ($settings['default_template']['setting_value'] ?? 'clean')=='modern'?'selected':'' ?>>Modern</option>
              <option value="elegant" <?= ($settings['default_template']['setting_value'] ?? 'clean')=='elegant'?'selected':'' ?>>Elegant</option>
              <option value="creative" <?= ($settings['default_template']['setting_value'] ?? 'clean')=='creative'?'selected':'' ?>>Creative</option>
            </select>
          </div>
          <div class="form-group">
            <label>Enable CV Downloads</label>
            <select name="setting_enable_downloads" class="form-select">
              <option value="1" <?= ($settings['enable_downloads']['setting_value'] ?? '1')=='1'?'selected':'' ?>>Yes - Enable PDF downloads</option>
              <option value="0" <?= ($settings['enable_downloads']['setting_value'] ?? '1')=='0'?'selected':'' ?>>No - Disable downloads</option>
            </select>
          </div>
          <div class="form-group">
            <label>Maintenance Mode</label>
            <select name="setting_maintenance_mode" class="form-select">
              <option value="0" <?= ($settings['maintenance_mode']['setting_value'] ?? '0')=='0'?'selected':'' ?>>Off - Site is live</option>
              <option value="1" <?= ($settings['maintenance_mode']['setting_value'] ?? '0')=='1'?'selected':'' ?>>On - Maintenance mode</option>
            </select>
          </div>
          <button type="submit" class="btn-sm btn-primary" style="padding:0.6rem 1.4rem"><i class="fas fa-save"></i> Save Settings</button>
        </form>
      </div>
    </div>
  </div>

  <!-- Database Info Card -->
  <div class="card" style="margin-top:0.4rem">
    <div class="card-header"><div class="card-title"><i class="fas fa-database" style="color:#f59e0b"></i> System Information</div></div>
    <div style="padding:1.4rem;display:grid;grid-template-columns:repeat(3,1fr);gap:1rem">
      <?php
      $infos = [
        ['label'=>'PHP Version','value'=>phpversion(),'icon'=>'fas fa-code','color'=>'#6366f1'],
        ['label'=>'Server Software','value'=>substr($_SERVER['SERVER_SOFTWARE']??'N/A',0,30),'icon'=>'fas fa-server','color'=>'#10b981'],
        ['label'=>'Max Upload Size','value'=>ini_get('upload_max_filesize'),'icon'=>'fas fa-upload','color'=>'#f59e0b'],
      ];
      foreach($infos as $info): ?>
      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:1rem;display:flex;align-items:center;gap:0.8rem">
        <div style="width:40px;height:40px;border-radius:10px;background:<?= $info['color'] ?>18;display:flex;align-items:center;justify-content:center;color:<?= $info['color'] ?>;font-size:1.1rem;flex-shrink:0"><i class="<?= $info['icon'] ?>"></i></div>
        <div>
          <div style="font-size:0.75rem;color:#64748b;font-weight:600"><?= $info['label'] ?></div>
          <div style="font-size:0.9rem;font-weight:700;color:#1e293b"><?= htmlspecialchars($info['value']) ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php require_once 'includes/footer.php'; ?>
