<?php
$pageTitle = 'My Favorites';
require_once 'includes/header.php';
$cid = $_SESSION['candidate_id'];

// Handle remove
if (isset($_GET['remove'])) {
    $rid = intval($_GET['remove']);
    $db->prepare("DELETE FROM favorites WHERE user_id=? AND template_id=?")->execute([$cid, $rid]);
    setFlash('success', 'Removed from favorites.');
    header('Location: favorites.php'); exit;
}

$favs = $db->prepare("SELECT f.*, t.title, t.description, t.file_type, t.download_count, t.preview_image, c.name as cat_name, c.icon as cat_icon 
    FROM favorites f 
    JOIN downloadable_templates t ON f.template_id=t.id 
    JOIN template_categories c ON t.category_id=c.id 
    WHERE f.user_id=? ORDER BY f.created_at DESC");
$favs->execute([$cid]);
$favs = $favs->fetchAll();
?>
<div class="topbar">
    <div class="page-title"><i class="fas fa-heart" style="color:#ef4444"></i> My Favorites</div>
</div>
<div class="content" style="padding:1.5rem">
    <div style="margin-bottom:1.5rem">
        <h2 style="font-family:'Sora',sans-serif;font-size:1.3rem;font-weight:700">Saved Templates</h2>
        <p style="color:#64748b;font-size:0.85rem"><?= count($favs) ?> template(s) saved.</p>
    </div>
    <?php if(empty($favs)): ?>
    <div style="text-align:center;padding:3rem;color:#475569">
        <i class="fas fa-heart" style="font-size:3rem;display:block;margin-bottom:1rem;opacity:0.3"></i>
        <p>No favorites yet. <a href="<?= SITE_URL ?>/templates_browse.php" style="color:var(--accent)">Browse templates</a></p>
    </div>
    <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1.2rem;">
    <?php foreach($favs as $fv): ?>
    <div style="background:#1e293b;border:1px solid rgba(255,255,255,0.07);border-radius:14px;overflow:hidden;">
        <div style="aspect-ratio:3/4;background:#2d3748;display:flex;align-items:center;justify-content:center;">
            <i class="fas <?= $fv['cat_icon'] ?>" style="font-size:2.5rem;color:#475569"></i>
        </div>
        <div style="padding:1rem">
            <div style="font-size:0.72rem;color:#6366f1;font-weight:600;text-transform:uppercase;margin-bottom:0.3rem"><?= htmlspecialchars($fv['cat_name']) ?></div>
            <div style="font-family:'Sora',sans-serif;font-weight:700;font-size:0.9rem;color:#f1f5f9;margin-bottom:0.5rem"><?= htmlspecialchars($fv['title']) ?></div>
            <div style="display:flex;gap:0.5rem">
                <a href="<?= SITE_URL ?>/download.php?id=<?= $fv['template_id'] ?>" style="flex:1;background:#6366f1;color:#fff;padding:0.45rem;border-radius:8px;font-size:0.78rem;font-weight:700;text-align:center;text-decoration:none"><i class="fas fa-download me-1"></i>Download</a>
                <a href="?remove=<?= $fv['template_id'] ?>" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:#f87171;padding:0.45rem 0.7rem;border-radius:8px;font-size:0.78rem;text-decoration:none" onclick="return confirm('Remove from favorites?')"><i class="fas fa-trash"></i></a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php require_once 'includes/footer.php'; ?>
