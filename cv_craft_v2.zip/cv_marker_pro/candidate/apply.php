<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireCandidate();
header('Location: ' . CANDIDATE_URL . '/cv_builder.php');
exit;
