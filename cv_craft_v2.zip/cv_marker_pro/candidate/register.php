<?php
require_once dirname(__DIR__) . '/includes/config.php';
if (isset($_SESSION['candidate_id'])) { header('Location: dashboard.php'); exit; }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username   = sanitize($_POST['username'] ?? '');
    $first_name = sanitize($_POST['first_name'] ?? '');
    $last_name  = sanitize($_POST['last_name'] ?? '');
    $email      = sanitize($_POST['email'] ?? '');
    $password   = $_POST['password'] ?? '';
    $confirm    = $_POST['confirm_password'] ?? '';
    $phone      = sanitize($_POST['phone'] ?? '');
    $city       = sanitize($_POST['city'] ?? '');
    $gender     = sanitize($_POST['gender'] ?? '');

    // Validation
    if (!$username || strlen($username) < 3)            $errors[] = 'Username must be at least 3 characters.';
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username))   $errors[] = 'Username: only letters, numbers, underscore.';
    if (!$first_name)                                    $errors[] = 'First name is required.';
    if (!$last_name)                                     $errors[] = 'Last name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))      $errors[] = 'Valid email is required.';
    if (strlen($password) < 8)                           $errors[] = 'Password must be at least 8 characters.';
    if (!preg_match('/[A-Z]/', $password))               $errors[] = 'Password must contain at least one uppercase letter.';
    if (!preg_match('/[0-9]/', $password))               $errors[] = 'Password must contain at least one number.';
    if ($password !== $confirm)                          $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $db = getDB();
        $chkEmail = $db->prepare("SELECT id FROM candidates WHERE email=?");
        $chkEmail->execute([$email]);
        $chkUser  = $db->prepare("SELECT id FROM candidates WHERE username=?");
        $chkUser->execute([$username]);

        if ($chkEmail->fetch())  $errors[] = 'This email is already registered.';
        if ($chkUser->fetch())   $errors[] = 'This username is already taken.';

        if (empty($errors)) {
            $appId = 'APP-' . strtoupper(substr(md5(uniqid()), 0, 8));
            $db->prepare("INSERT INTO candidates (username,first_name,last_name,email,password,phone,city,gender,application_id) VALUES(?,?,?,?,?,?,?,?,?)")
               ->execute([$username, $first_name, $last_name, $email, hashPassword($password), $phone, $city, $gender ?: null, $appId]);
            $newId = $db->lastInsertId();
            logActivity('candidate', $newId, 'REGISTER', 'New candidate registered');
            setFlash('success', 'Account created! Please login. Your Application ID: ' . $appId);
            header('Location: ../login.php'); exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account — CV Craft</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Sora:wght@700;800&display=swap" rel="stylesheet">
<link href="../includes/common.css" rel="stylesheet">
<style>
body{font-family:'Inter',sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem 1rem;background-image:radial-gradient(ellipse at 30% 50%,rgba(16,185,129,0.07) 0%,transparent 60%);}
.reg-card{width:100%;max-width:600px;background:#1e293b;border:1px solid rgba(255,255,255,0.08);border-radius:20px;padding:2.5rem;box-shadow:0 24px 48px rgba(0,0,0,0.4);}
.section-divider{font-size:0.7rem;font-weight:700;color:#10b981;text-transform:uppercase;letter-spacing:0.1em;padding:0.5rem 0;border-bottom:1px solid rgba(16,185,129,0.2);margin:1.2rem 0 1rem;}
.fc{background:rgba(255,255,255,0.05)!important;border:1px solid rgba(255,255,255,0.1)!important;color:#e2e8f0!important;border-radius:10px!important;padding:0.65rem 1rem!important;font-size:0.88rem;transition:border-color 0.2s;}
.fc:focus{border-color:#10b981!important;box-shadow:0 0 0 3px rgba(16,185,129,0.15)!important;}
.fc::placeholder{color:#475569!important;}
.fc.is-invalid-c{border-color:#ef4444!important;}
.fc.is-valid-c{border-color:#10b981!important;}
.form-label{font-size:0.8rem;color:#94a3b8;font-weight:500;margin-bottom:0.3rem;}
.ig-text{background:rgba(255,255,255,0.05)!important;border:1px solid rgba(255,255,255,0.1)!important;color:#94a3b8;cursor:pointer;transition:color 0.2s;}
.ig-text:hover{color:#e2e8f0;}
.btn-register{width:100%;padding:0.8rem;background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:none;border-radius:10px;font-family:'Sora',sans-serif;font-weight:700;font-size:0.95rem;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;margin-top:0.5rem;}
.btn-register:hover{transform:translateY(-1px);box-shadow:0 8px 20px rgba(16,185,129,0.4);}
.pwd-strength{height:4px;border-radius:2px;margin-top:0.4rem;transition:all 0.3s;background:#334155;}
.pwd-strength-bar{height:100%;border-radius:2px;transition:width 0.3s,background 0.3s;width:0%;}
.field-err{color:#f87171;font-size:0.75rem;margin-top:0.2rem;display:none;}
.err-alert{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#fca5a5;border-radius:10px;padding:0.75rem 1rem;font-size:0.83rem;margin-bottom:1rem;}
</style>
</head>
<body>
<div id="toaster-container"></div>
<div class="reg-card">
  <div class="text-center mb-4">
    <div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#10b981,#059669);display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin:0 auto 0.8rem"><i class="fas fa-user-plus text-white"></i></div>
    <h1 class="h4 fw-bold mb-1" style="font-family:'Sora',sans-serif;color:#f1f5f9">Create Account</h1>
    <p style="color:#64748b;font-size:0.83rem">Join CV Craft — Build your professional CV today</p>
  </div>

  <?php if (!empty($errors)): ?>
  <div class="err-alert">
    <?php foreach($errors as $e): ?><div><i class="fas fa-times-circle me-1"></i><?= htmlspecialchars($e) ?></div><?php endforeach; ?>
  </div>
  <?php endif; ?>

  <form method="POST" id="regForm" novalidate>

    <div class="section-divider"><i class="fas fa-id-card me-1"></i>Account Information</div>
    <div class="mb-3">
      <label class="form-label">Username <span style="color:#f87171">*</span></label>
      <input type="text" name="username" id="fUsername" class="fc form-control"
             placeholder="e.g. ahmed_dev" value="<?= htmlspecialchars($_POST['username']??'') ?>">
      <div class="field-err" id="eUsername">Username must be 3+ chars, letters/numbers/underscore only.</div>
      <div style="font-size:0.73rem;color:#475569;margin-top:0.2rem">Used for login. No spaces allowed.</div>
    </div>

    <div class="section-divider"><i class="fas fa-user me-1"></i>Personal Information</div>
    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">First Name <span style="color:#f87171">*</span></label>
        <input type="text" name="first_name" id="fFirstName" class="fc form-control"
               placeholder="Muhammad" value="<?= htmlspecialchars($_POST['first_name']??'') ?>">
        <div class="field-err" id="eFirstName">First name is required.</div>
      </div>
      <div class="col-md-6">
        <label class="form-label">Last Name <span style="color:#f87171">*</span></label>
        <input type="text" name="last_name" id="fLastName" class="fc form-control"
               placeholder="Ahmed" value="<?= htmlspecialchars($_POST['last_name']??'') ?>">
        <div class="field-err" id="eLastName">Last name is required.</div>
      </div>
    </div>

    <div class="row g-3 mt-0">
      <div class="col-md-6 mt-3">
        <label class="form-label">Phone Number</label>
        <input type="tel" name="phone" class="fc form-control" placeholder="+92 300 1234567" value="<?= htmlspecialchars($_POST['phone']??'') ?>">
      </div>
      <div class="col-md-6 mt-3">
        <label class="form-label">City</label>
        <input type="text" name="city" class="fc form-control" placeholder="Lahore" value="<?= htmlspecialchars($_POST['city']??'') ?>">
      </div>
    </div>

    <div class="mt-3">
      <label class="form-label">Gender</label>
      <select name="gender" class="fc form-control form-select">
        <option value="">Prefer not to say</option>
        <option value="male" <?= ($_POST['gender']??'')==='male'?'selected':'' ?>>Male</option>
        <option value="female" <?= ($_POST['gender']??'')==='female'?'selected':'' ?>>Female</option>
        <option value="other" <?= ($_POST['gender']??'')==='other'?'selected':'' ?>>Other</option>
      </select>
    </div>

    <div class="section-divider mt-4"><i class="fas fa-lock me-1"></i>Login Credentials</div>
    <div class="mb-3">
      <label class="form-label">Email Address <span style="color:#f87171">*</span></label>
      <input type="email" name="email" id="fEmail" class="fc form-control"
             placeholder="you@example.com" value="<?= htmlspecialchars($_POST['email']??'') ?>">
      <div class="field-err" id="eEmail">Please enter a valid email address.</div>
    </div>

    <div class="mb-3">
      <label class="form-label">Password <span style="color:#f87171">*</span></label>
      <div class="input-group">
        <input type="password" name="password" id="fPassword" class="fc form-control" placeholder="Min 8 chars, 1 uppercase, 1 number" style="border-radius:10px 0 0 10px!important;border-right:none!important">
        <span class="ig-text input-group-text" onclick="togglePwd('fPassword','eye1')" style="border-radius:0 10px 10px 0;border-left:none"><i class="fas fa-eye" id="eye1"></i></span>
      </div>
      <div class="pwd-strength"><div class="pwd-strength-bar" id="strengthBar"></div></div>
      <div style="font-size:0.72rem;margin-top:0.2rem" id="strengthText"></div>
      <div class="field-err" id="ePassword">Min 8 chars, 1 uppercase letter, 1 number required.</div>
    </div>

    <div class="mb-3">
      <label class="form-label">Confirm Password <span style="color:#f87171">*</span></label>
      <div class="input-group">
        <input type="password" name="confirm_password" id="fConfirm" class="fc form-control" placeholder="Re-enter password" style="border-radius:10px 0 0 10px!important;border-right:none!important">
        <span class="ig-text input-group-text" onclick="togglePwd('fConfirm','eye2')" style="border-radius:0 10px 10px 0;border-left:none"><i class="fas fa-eye" id="eye2"></i></span>
      </div>
      <div class="field-err" id="eConfirm">Passwords do not match.</div>
    </div>

    <button type="submit" class="btn-register" id="regBtn">
      <i class="fas fa-user-plus"></i> Create My Account
    </button>
  </form>

  <div style="text-align:center;margin-top:1.2rem;font-size:0.85rem;color:#64748b">
    Already have an account? <a href="<?= SITE_URL ?>/login.php" style="color:#10b981;text-decoration:none;font-weight:600">Sign In</a>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="../includes/common.js"></script>
<script>
function togglePwd(id, ico){
    var f=$('#'+id)[0], i=$('#'+ico)[0];
    if(f.type==='password'){f.type='text';i.className='fas fa-eye-slash';}
    else{f.type='password';i.className='fas fa-eye';}
}

function checkStrength(p){
    var s=0,text='',color='';
    if(p.length>=8)s++;
    if(/[A-Z]/.test(p))s++;
    if(/[0-9]/.test(p))s++;
    if(/[^A-Za-z0-9]/.test(p))s++;
    if(p.length<4){s=0;}
    var pct=[0,25,50,75,100][s]||0;
    var colors=['','#ef4444','#f59e0b','#3b82f6','#10b981'];
    var texts=['','Weak','Fair','Good','Strong'];
    var tcolors=['','#f87171','#fbbf24','#60a5fa','#34d399'];
    $('#strengthBar').css({width:pct+'%',background:colors[s]||'#334155'});
    $('#strengthText').html(s>0?'<span style="color:'+tcolors[s]+'">'+texts[s]+'</span>':'').css('color','');
}

$(function(){
    // Real-time password strength
    $('#fPassword').on('input',function(){ checkStrength($(this).val()); });

    // Username validation
    $('#fUsername').on('input',function(){
        var v=$(this).val();
        if(v.length>=3 && /^[a-zA-Z0-9_]+$/.test(v)){$(this).addClass('is-valid-c').removeClass('is-invalid-c');$('#eUsername').hide();}
        else if(v.length>0){$(this).addClass('is-invalid-c').removeClass('is-valid-c');$('#eUsername').show();}
        else{$(this).removeClass('is-valid-c is-invalid-c');$('#eUsername').hide();}
    });

    // Email validation
    $('#fEmail').on('input',function(){
        var emailReg=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if(emailReg.test($(this).val())){$(this).addClass('is-valid-c').removeClass('is-invalid-c');$('#eEmail').hide();}
        else if($(this).val().length>0){$(this).addClass('is-invalid-c').removeClass('is-valid-c');$('#eEmail').show();}
    });

    // Confirm password match
    $('#fConfirm').on('input',function(){
        if($(this).val()===$('#fPassword').val()){$(this).addClass('is-valid-c').removeClass('is-invalid-c');$('#eConfirm').hide();}
        else{$(this).addClass('is-invalid-c').removeClass('is-valid-c');$('#eConfirm').show();}
    });

    // Form submit validation
    $('#regForm').on('submit',function(e){
        var ok=true;

        if(!$('#fUsername').val() || $('#fUsername').val().length<3 || !/^[a-zA-Z0-9_]+$/.test($('#fUsername').val())){
            $('#eUsername').show();ok=false;
        }
        if(!$('#fFirstName').val()){$('#eFirstName').show();ok=false;}else{$('#eFirstName').hide();}
        if(!$('#fLastName').val()){$('#eLastName').show();ok=false;}else{$('#eLastName').hide();}

        var emailReg=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if(!emailReg.test($('#fEmail').val())){$('#eEmail').show();ok=false;}else{$('#eEmail').hide();}

        var pwd=$('#fPassword').val();
        if(pwd.length<8 || !/[A-Z]/.test(pwd) || !/[0-9]/.test(pwd)){$('#ePassword').show();ok=false;}else{$('#ePassword').hide();}

        if($('#fConfirm').val()!==pwd){$('#eConfirm').show();ok=false;}else{$('#eConfirm').hide();}

        if(!ok){
            e.preventDefault();
            showToast('Please fix the form errors.','danger');
            return;
        }
        $('#regBtn').html('<i class="fas fa-spinner fa-spin"></i> Creating account...').prop('disabled',true);
    });
});
</script>
</body>
</html>
