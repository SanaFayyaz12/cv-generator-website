<?php
$pageTitle = 'My Profile';
require_once 'includes/header.php';

$cid = $_SESSION['candidate_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $first_name = sanitize($_POST['first_name'] ?? '');
        $phone     = sanitize($_POST['phone'] ?? '');
        $city      = sanitize($_POST['city'] ?? '');
        $gender    = sanitize($_POST['gender'] ?? '');
        $dob       = sanitize($_POST['date_of_birth'] ?? '');

        if ($first_name) {
            $stmt = $db->prepare("UPDATE candidates SET first_name=?,phone=?,city=?,gender=?,date_of_birth=? WHERE id=?");
            $stmt->execute([$first_name, $phone, $city, $gender ?: null, $dob ?: null, $cid]);
            $_SESSION['candidate_name'] = $first_name;
            setFlash('success', 'Profile updated successfully!');
        } else {
            setFlash('danger', 'Full name is required.');
        }
    } elseif ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        $candCheck = $db->prepare("SELECT password FROM candidates WHERE id=?");
        $candCheck->execute([$cid]);
        $candCheck = $candCheck->fetch();

        if (!verifyPassword($current, $candCheck['password'])) {
            setFlash('danger', 'Current password is incorrect.');
        } elseif (strlen($new) < 6) {
            setFlash('danger', 'New password must be at least 6 characters.');
        } elseif ($new !== $confirm) {
            setFlash('danger', 'New passwords do not match.');
        } else {
            $db->prepare("UPDATE candidates SET password=? WHERE id=?")->execute([hashPassword($new), $cid]);
            setFlash('success', 'Password changed successfully!');
        }
    }

    header('Location: profile.php');
    exit;
}

// Refresh candidate data
$cStmt = $db->prepare("SELECT * FROM candidates WHERE id=?");
$cStmt->execute([$cid]);
$currentCandidate = $cStmt->fetch();
?>
<div class="topbar">
    <div class="page-title"><i class="fas fa-user-circle" style="color:var(--accent)"></i> My Profile</div>
</div>
<div class="content">
    <div class="row">
        <div class="col-8">
            <!-- Profile Update -->
            <div class="card">
                <div class="card-header"><div class="card-title">Personal Information</div></div>
                <form method="POST">
                    <input type="hidden" name="action" value="update_profile">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Full Name *</label>
                                <input type="text" name="first_name" class="form-control" required value="<?= htmlspecialchars($currentCandidate['first_name']) ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Email (read-only)</label>
                                <input type="email" class="form-control" disabled value="<?= htmlspecialchars($currentCandidate['email']) ?>" style="opacity:0.5">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Phone</label>
                                <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($currentCandidate['phone'] ?? '') ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">City</label>
                                <input type="text" name="city" class="form-control" value="<?= htmlspecialchars($currentCandidate['city'] ?? '') ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Gender</label>
                                <select name="gender" class="form-control">
                                    <option value="">— Select —</option>
                                    <?php foreach (['male','female','other'] as $g): ?>
                                    <option value="<?= $g ?>" <?= ($currentCandidate['gender'] ?? '') === $g ? 'selected' : '' ?>><?= ucfirst($g) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Date of Birth</label>
                                <input type="date" name="date_of_birth" class="form-control" value="<?= htmlspecialchars($currentCandidate['date_of_birth'] ?? '') ?>">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Profile</button>
                </form>
            </div>

            <!-- Password Change -->
            <div class="card">
                <div class="card-header"><div class="card-title">Change Password</div></div>
                <form method="POST">
                    <input type="hidden" name="action" value="change_password">
                    <div class="form-group">
                        <label class="form-label">Current Password</label>
                        <input type="password" name="current_password" class="form-control" required placeholder="Enter current password">
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">New Password</label>
                                <input type="password" name="new_password" class="form-control" required placeholder="Min. 6 characters">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Confirm New Password</label>
                                <input type="password" name="confirm_password" class="form-control" required placeholder="Repeat new password">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-warning"><i class="fas fa-lock"></i> Change Password</button>
                </form>
            </div>
        </div>

        <!-- Summary card -->
        <div class="col-6" style="min-width:220px;max-width:280px">
            <div class="card" style="text-align:center">
                <div style="width:70px;height:70px;background:var(--accent);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.8rem;font-weight:700;color:#fff;margin:0 auto 1rem">
                    <?= strtoupper(substr($currentCandidate['first_name'],0,1)) ?>
                </div>
                <h3 style="font-family:'Sora',sans-serif"><?= htmlspecialchars($currentCandidate['first_name']) ?></h3>
                <p style="color:var(--text-muted);font-size:0.82rem;margin-top:0.3rem"><?= htmlspecialchars($currentCandidate['email']) ?></p>
                <?php if ($currentCandidate['city']): ?>
                <p style="color:var(--text-muted);font-size:0.8rem;margin-top:0.3rem"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($currentCandidate['city']) ?></p>
                <?php endif; ?>
                <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border);font-size:0.82rem;color:var(--text-muted)">
                    Member since <?= formatDate($currentCandidate['created_at'], 'M Y') ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
