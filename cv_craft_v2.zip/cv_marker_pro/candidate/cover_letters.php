<?php
$pageTitle = 'Cover Letters';
require_once 'includes/header.php';
$cid = $_SESSION['candidate_id'];
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $db->prepare('DELETE FROM cover_letters WHERE id=? AND candidate_id=?')->execute([$id, $cid]);
    logActivity('candidate', $cid, 'DELETE_COVER_LETTER', 'Deleted cover letter');
    setFlash('success', 'Cover letter deleted.');
    header('Location: cover_letters.php');
    exit;
}
$editing = null;
if (isset($_GET['id'])) {
    $stmt = $db->prepare('SELECT * FROM cover_letters WHERE id=? AND candidate_id=?');
    $stmt->execute([(int)$_GET['id'], $cid]);
    $editing = $stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $title = sanitize($_POST['title'] ?? 'Cover Letter');
    $name = sanitize($_POST['applicant_name'] ?? '');
    $company = sanitize($_POST['company'] ?? '');
    $position = sanitize($_POST['position'] ?? '');
    $template = sanitize($_POST['template'] ?? 'formal');
    $message = trim($_POST['message'] ?? '');
    if ($name && $company && $position && $message) {
        if ($id > 0) {
            $db->prepare('UPDATE cover_letters SET title=?, applicant_name=?, company=?, position=?, template=?, message=? WHERE id=? AND candidate_id=?')->execute([$title,$name,$company,$position,$template,$message,$id,$cid]);
            setFlash('success', 'Cover letter updated.');
        } else {
            $db->prepare('INSERT INTO cover_letters (candidate_id,title,applicant_name,company,position,template,message) VALUES (?,?,?,?,?,?,?)')->execute([$cid,$title,$name,$company,$position,$template,$message]);
            setFlash('success', 'Cover letter saved.');
        }
        logActivity('candidate', $cid, 'SAVE_COVER_LETTER', 'Saved cover letter');
        header('Location: cover_letters.php');
        exit;
    } else {
        setFlash('danger', 'Please fill all required fields.');
    }
}
$list = $db->prepare('SELECT * FROM cover_letters WHERE candidate_id=? ORDER BY updated_at DESC');
$list->execute([$cid]);
$letters = $list->fetchAll();
$nameDefault = getCandidateName($currentCandidate ?: []);
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<style>
.cl-grid{display:grid;grid-template-columns:minmax(320px,420px) 1fr;gap:1.2rem}.cl-preview{background:#f8fafc;color:#1e293b;min-height:620px;border-radius:16px;padding:42px;box-shadow:0 20px 40px rgba(0,0,0,.25);font-family:Georgia,serif}.cl-preview.modern{font-family:Inter,sans-serif;border-top:12px solid #6366f1}.cl-preview.minimal{font-family:Arial,sans-serif;border:1px solid #e2e8f0;box-shadow:none}.cl-preview h1{font-size:28px;margin:0 0 10px}.cl-preview .meta{color:#64748b;margin-bottom:30px}.cl-preview p{line-height:1.75;white-space:pre-wrap}@media(max-width:900px){.cl-grid{grid-template-columns:1fr}}
</style>
<div class="topbar">
    <div class="page-title"><i class="fas fa-envelope-open-text" style="color:var(--accent)"></i> Cover Letter Builder</div>
    <div class="topbar-actions"><button class="topbar-btn primary" onclick="downloadLetter()"><i class="fas fa-download"></i> Download PDF</button></div>
</div>
<div class="content">
    <div class="cl-grid">
        <div class="card">
            <div class="card-header"><div class="card-title"><?= $editing ? 'Edit Cover Letter' : 'Create Cover Letter' ?></div></div>
            <form method="POST" id="letterForm">
                <input type="hidden" name="id" value="<?= (int)($editing['id'] ?? 0) ?>">
                <div class="mb-3"><label class="form-label">Title</label><input class="form-control" name="title" id="clTitle" value="<?= htmlspecialchars($editing['title'] ?? 'Cover Letter') ?>" oninput="updateLetter()"></div>
                <div class="mb-3"><label class="form-label">Your Name *</label><input class="form-control" name="applicant_name" id="clName" required value="<?= htmlspecialchars($editing['applicant_name'] ?? $nameDefault) ?>" oninput="updateLetter()"></div>
                <div class="mb-3"><label class="form-label">Company *</label><input class="form-control" name="company" id="clCompany" required value="<?= htmlspecialchars($editing['company'] ?? '') ?>" oninput="updateLetter()"></div>
                <div class="mb-3"><label class="form-label">Position *</label><input class="form-control" name="position" id="clPosition" required value="<?= htmlspecialchars($editing['position'] ?? '') ?>" oninput="updateLetter()"></div>
                <div class="mb-3"><label class="form-label">Template</label><select class="form-select" name="template" id="clTemplate" onchange="updateLetter()"><option value="formal">Formal</option><option value="modern">Modern</option><option value="minimal">Minimal</option></select></div>
                <div class="mb-3"><label class="form-label">Message *</label><textarea class="form-control" name="message" id="clMessage" rows="8" required oninput="updateLetter()"><?= htmlspecialchars($editing['message'] ?? 'I am writing to express my interest in this position. My background, skills and motivation make me a strong candidate for your team. I would welcome the opportunity to discuss how I can contribute to your organization.') ?></textarea></div>
                <button class="btn btn-success w-100" type="submit"><i class="fas fa-save"></i> Save Cover Letter</button>
            </form>
        </div>
        <div class="cl-preview" id="letterPreview"></div>
    </div>
    <div class="card mt-4"><div class="card-header"><div class="card-title">Saved Cover Letters</div></div>
        <div class="table-wrap"><table><thead><tr><th>Title</th><th>Company</th><th>Position</th><th>Updated</th><th>Actions</th></tr></thead><tbody>
        <?php if(empty($letters)): ?><tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:1.5rem">No cover letters saved yet.</td></tr><?php endif; ?>
        <?php foreach($letters as $l): ?><tr><td><?= htmlspecialchars($l['title']) ?></td><td><?= htmlspecialchars($l['company']) ?></td><td><?= htmlspecialchars($l['position']) ?></td><td><?= formatDate($l['updated_at'], 'd M Y h:i A') ?></td><td><a class="btn btn-info btn-sm" href="cover_letters.php?id=<?= $l['id'] ?>">Edit</a> <a class="btn btn-danger btn-sm" onclick="return confirm('Delete this cover letter?')" href="cover_letters.php?delete=<?= $l['id'] ?>"><i class="fas fa-trash"></i></a></td></tr><?php endforeach; ?>
        </tbody></table></div>
    </div>
</div>
<script>
function esc(s){const d=document.createElement('div');d.textContent=s||'';return d.innerHTML}
function updateLetter(){const p=document.getElementById('letterPreview'),tpl=document.getElementById('clTemplate').value;p.className='cl-preview '+tpl;const n=esc(document.getElementById('clName').value||'Your Name'),c=esc(document.getElementById('clCompany').value||'Company'),pos=esc(document.getElementById('clPosition').value||'Position'),m=esc(document.getElementById('clMessage').value||'');p.innerHTML='<h1>'+n+'</h1><div class="meta">Application for '+pos+' at '+c+'</div><p>Dear Hiring Manager,</p><p>'+m+'</p><p>Sincerely,<br><strong>'+n+'</strong></p>';}
function downloadLetter(){html2pdf().set({margin:10,filename:(document.getElementById('clTitle').value||'Cover_Letter').replace(/\s+/g,'_')+'.pdf',image:{type:'jpeg',quality:.98},html2canvas:{scale:2},jsPDF:{unit:'mm',format:'a4',orientation:'portrait'}}).from(document.getElementById('letterPreview')).save();}
document.getElementById('clTemplate').value='<?= htmlspecialchars($editing['template'] ?? 'formal') ?>';updateLetter();
</script>
<?php require_once 'includes/footer.php'; ?>