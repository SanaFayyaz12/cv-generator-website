<?php
require_once dirname(__DIR__) . '/includes/config.php';
requireCandidate();
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}
$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
    echo json_encode(['success' => false, 'message' => 'Invalid CV data.']);
    exit;
}
$id = (int)($payload['id'] ?? 0);
$title = sanitize($payload['title'] ?? 'Untitled CV');
$template = sanitize($payload['template'] ?? 'clean');
$data = $payload['data'] ?? [];
if (!$title) $title = 'Untitled CV';
$json = json_encode($data, JSON_UNESCAPED_UNICODE);
$db = getDB();
try {
    if ($id > 0) {
        $stmt = $db->prepare('UPDATE cvs SET title=?, template=?, data_json=? WHERE id=? AND candidate_id=?');
        $stmt->execute([$title, $template, $json, $id, $_SESSION['candidate_id']]);
        if ($stmt->rowCount() === 0) {
            echo json_encode(['success' => false, 'message' => 'CV not found.']);
            exit;
        }
        logActivity('candidate', $_SESSION['candidate_id'], 'UPDATE_CV', 'Updated saved CV');
    } else {
        $stmt = $db->prepare('INSERT INTO cvs (candidate_id,title,template,data_json) VALUES (?,?,?,?)');
        $stmt->execute([$_SESSION['candidate_id'], $title, $template, $json]);
        $id = (int)$db->lastInsertId();
        logActivity('candidate', $_SESSION['candidate_id'], 'CREATE_CV', 'Created saved CV');
    }
    echo json_encode(['success' => true, 'id' => $id, 'message' => 'CV saved successfully.']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to save CV.']);
}
?>