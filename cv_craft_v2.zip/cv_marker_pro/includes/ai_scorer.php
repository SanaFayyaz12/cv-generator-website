<?php
function scoreCV($applicationId) {
    require_once __DIR__ . '/config.php';
    $db = getDB();
    $stmt = $db->prepare("SELECT a.*, CONCAT(c.first_name, ' ', c.last_name) as full_name, c.email, j.title as job_title, j.required_skills, j.description as job_description, j.min_experience, j.education_required, j.total_marks FROM cv_applications a JOIN candidates c ON a.candidate_id = c.id JOIN job_positions j ON a.position_id = j.id WHERE a.id = ?");
    $stmt->execute([$applicationId]);
    $app = $stmt->fetch();
    if (!$app) return false;
    $aiResult = localCvScoring($app);
    $checkStmt = $db->prepare("SELECT id FROM cv_scores WHERE application_id = ?");
    $checkStmt->execute([$applicationId]);
    $existing = $checkStmt->fetch();
    if ($existing) {
        $updateStmt = $db->prepare("UPDATE cv_scores SET ai_education_score=?, ai_experience_score=?, ai_skills_score=?, ai_overall_score=?, ai_feedback=?, final_score=?, scoring_method='ai' WHERE application_id=?");
        $updateStmt->execute([$aiResult['education_score'],$aiResult['experience_score'],$aiResult['skills_score'],$aiResult['overall_score'],$aiResult['feedback'],$aiResult['overall_score'],$applicationId]);
    } else {
        $insertStmt = $db->prepare("INSERT INTO cv_scores (application_id, ai_education_score, ai_experience_score, ai_skills_score, ai_overall_score, ai_feedback, final_score, scoring_method) VALUES (?,?,?,?,?,?,?,'ai')");
        $insertStmt->execute([$applicationId,$aiResult['education_score'],$aiResult['experience_score'],$aiResult['skills_score'],$aiResult['overall_score'],$aiResult['feedback'],$aiResult['overall_score']]);
    }
    $db->prepare("UPDATE cv_applications SET status = 'scored' WHERE id = ?")->execute([$applicationId]);
    createNotification($app['candidate_id'], $applicationId, 'scored', 'Your CV Has Been Scored', 'Your CV for ' . $app['job_title'] . ' has been evaluated. Login to view your score and feedback.');
    return $aiResult;
}

function localCvScoring($app) {
    $required = splitKeywords(($app['required_skills'] ?? '') . ',' . ($app['job_description'] ?? ''));
    $candidate = splitKeywords(($app['skills'] ?? '') . ',' . ($app['certifications'] ?? '') . ',' . ($app['current_designation'] ?? ''));
    $matched = array_values(array_intersect($required, $candidate));
    $missing = array_values(array_diff($required, $candidate));
    $skillPct = count($required) ? round((count($matched) / count($required)) * 100) : 70;
    $skillsScore = min(25, max(5, round($skillPct * 0.25)));
    $eduRank = ['matric'=>1,'intermediate'=>2,'bachelors'=>3,'masters'=>4,'phd'=>5,'any'=>0];
    $candidateEdu = strtolower($app['education_level'] ?? 'any');
    $requiredEdu = strtolower($app['education_required'] ?? 'any');
    $eduScore = ($requiredEdu === 'any' || ($eduRank[$candidateEdu] ?? 0) >= ($eduRank[$requiredEdu] ?? 0)) ? 25 : max(8, 12 + (($eduRank[$candidateEdu] ?? 0) * 2));
    $exp = (int)($app['total_experience'] ?? 0);
    $minExp = (int)($app['min_experience'] ?? 0);
    $expScore = $minExp <= 0 ? min(25, 14 + ($exp * 2)) : min(25, round(($exp / max(1, $minExp)) * 20));
    $presentation = 10;
    if (!empty($app['cover_letter']) && strlen($app['cover_letter']) > 120) $presentation += 6;
    if (!empty($app['linkedin_url'])) $presentation += 3;
    if (!empty($app['cv_file'])) $presentation += 3;
    if (!empty($app['certifications'])) $presentation += 3;
    $presentation = min(25, $presentation);
    $total = min(100, $eduScore + $expScore + $skillsScore + $presentation);
    $feedback = buildFeedback($total, $matched, $missing, $skillPct, $app);
    return [
        'education_score' => $eduScore,
        'experience_score' => $expScore,
        'skills_score' => $skillsScore,
        'overall_score' => $total,
        'skill_match_percentage' => $skillPct,
        'strengths' => array_slice(array_merge($matched, ['Education profile submitted', 'Experience details available']), 0, 3),
        'weaknesses' => array_slice($missing ?: ['Add more measurable achievements', 'Improve formatting consistency'], 0, 3),
        'recommendation' => $total >= 70 ? 'shortlist' : ($total >= 50 ? 'hold' : 'reject'),
        'feedback' => $feedback,
    ];
}

function splitKeywords($text) {
    $text = strtolower((string)$text);
    $parts = preg_split('/[^a-z0-9+#.]+/i', $text);
    $stop = ['and','or','the','for','with','job','role','required','needed','years','year','work','team','skills','skill','experience'];
    $out = [];
    foreach ($parts as $p) {
        $p = trim($p);
        if (strlen($p) >= 2 && !in_array($p, $stop, true)) $out[$p] = $p;
    }
    return array_values($out);
}

function buildFeedback($total, $matched, $missing, $skillPct, $app) {
    $level = $total >= 70 ? 'strong' : ($total >= 50 ? 'moderate' : 'weak');
    $feedback = "Overall profile match is {$level} with {$skillPct}% keyword alignment. ";
    if ($matched) $feedback .= 'Matched skills/keywords: ' . implode(', ', array_slice($matched, 0, 6)) . '. ';
    if ($missing) $feedback .= 'Missing or weak keywords: ' . implode(', ', array_slice($missing, 0, 6)) . '. ';
    if (empty($app['cover_letter'])) $feedback .= 'Add a focused cover letter to improve presentation score. ';
    $feedback .= 'Use measurable achievements, clean headings, and job-specific keywords for a better score.';
    return $feedback;
}

function compareCvToJob($cvData, $job) {
    if (is_string($cvData)) $cvData = json_decode($cvData, true) ?: [];
    $skills = $cvData['skills'] ?? [];
    $summary = $cvData['summary'] ?? '';
    $experience = $cvData['experience'] ?? [];
    $text = implode(',', $skills) . ' ' . $summary . ' ' . json_encode($experience);
    $required = splitKeywords(($job['required_skills'] ?? '') . ' ' . ($job['description'] ?? ''));
    $candidate = splitKeywords($text);
    $matched = array_values(array_intersect($required, $candidate));
    $missing = array_values(array_diff($required, $candidate));
    $pct = count($required) ? round((count($matched) / count($required)) * 100) : 65;
    return ['percentage'=>$pct,'matched'=>$matched,'missing'=>$missing,'suggestion'=>'Add missing keywords naturally in your summary, skills, and experience bullet points.'];
}

function generateCoverLetterText($candidateName, $job, $cvData = []) {
    $skills = isset($cvData['skills']) && is_array($cvData['skills']) ? implode(', ', array_slice($cvData['skills'], 0, 6)) : 'relevant technical and professional skills';
    return "Dear Hiring Manager,\n\nI am writing to apply for the {$job['title']} position. My background in {$skills} aligns well with your requirements, and I am confident that I can contribute value to your team.\n\nI have reviewed the role requirements and tailored my CV to highlight the most relevant education, experience, and project work. I would welcome the opportunity to discuss how my abilities can support your goals.\n\nSincerely,\n{$candidateName}";
}
?>