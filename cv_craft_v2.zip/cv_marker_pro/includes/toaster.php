<?php
// Toaster notifications - include this in any page
$flash = getFlash();
?>
<?php if($flash): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    showToast('<?= addslashes($flash['message']) ?>', '<?= $flash['type'] ?>');
});
</script>
<?php endif; ?>
