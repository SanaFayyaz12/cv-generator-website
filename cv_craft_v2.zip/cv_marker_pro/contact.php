<?php
require_once 'includes/config.php';
$sent = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sent = true;
    setFlash('success', 'Thank you for your message! We will get back to you soon.');
}
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Contact — <?= SITE_NAME ?></title>
<?php include 'includes/assets.php'; ?>
<link href="includes/common.css" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:#0a0f1e;color:#e2e8f0;}
.nav-top{position:sticky;top:0;z-index:100;background:rgba(10,15,30,0.95);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,0.06);padding:0.8rem 0;}
.nav-inner{max-width:1280px;margin:0 auto;padding:0 2rem;display:flex;align-items:center;justify-content:space-between;}
.brand{display:flex;align-items:center;gap:0.6rem;text-decoration:none;}
.brand-box{width:34px;height:34px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border-radius:8px;display:flex;align-items:center;justify-content:center;}
.brand-txt{font-family:'Sora',sans-serif;font-size:1.05rem;font-weight:800;color:#f1f5f9;}
.brand-txt span{color:#6366f1;}
.nav-links{display:flex;align-items:center;gap:1.5rem;}
.nav-links a{color:#94a3b8;font-size:0.85rem;font-weight:500;text-decoration:none;}
.nav-links a:hover,.nav-links a.active{color:#f1f5f9;}
.content{max-width:600px;margin:4rem auto;padding:0 2rem;}
.content h1{font-family:'Sora',sans-serif;font-size:2rem;font-weight:800;margin-bottom:0.5rem;color:#f1f5f9;}
.content .sub{color:#64748b;margin-bottom:2rem;}
.fg{margin-bottom:1.2rem;}
.fg label{display:block;font-size:0.82rem;color:#94a3b8;font-weight:500;margin-bottom:0.3rem;}
.fg input,.fg textarea{width:100%;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#e2e8f0;padding:0.7rem 1rem;border-radius:10px;font-size:0.88rem;font-family:'Inter',sans-serif;outline:none;transition:border-color 0.2s;}
.fg input:focus,.fg textarea:focus{border-color:#6366f1;}
.fg textarea{min-height:140px;resize:vertical;}
.btn-send{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;padding:0.8rem 2rem;border:none;border-radius:10px;font-weight:700;font-size:0.92rem;cursor:pointer;transition:all 0.3s;display:inline-flex;align-items:center;gap:0.5rem;}
.btn-send:hover{box-shadow:0 8px 20px rgba(99,102,241,0.4);transform:translateY(-2px);}
.contact-info{margin-top:3rem;display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1rem;}
.ci{background:#1e293b;border:1px solid rgba(255,255,255,0.07);border-radius:12px;padding:1.2rem;text-align:center;}
.ci i{font-size:1.3rem;color:#6366f1;margin-bottom:0.5rem;display:block;}
.ci h5{font-size:0.85rem;font-weight:700;color:#f1f5f9;margin-bottom:0.2rem;}
.ci p{font-size:0.78rem;color:#64748b;margin:0;}
.site-footer{background:#0f172a;border-top:1px solid rgba(255,255,255,0.06);padding:2rem 0;text-align:center;color:#475569;font-size:0.82rem;margin-top:3rem;}
</style>
</head>
<body>
<div id="toaster-container"></div>
<nav class="nav-top"><div class="nav-inner">
    <a href="<?= SITE_URL ?>" class="brand"><div class="brand-box"><i class="fas fa-file-alt" style="color:#fff;font-size:0.85rem"></i></div><span class="brand-txt">CV <span>Craft</span></span></a>
    <div class="nav-links d-none d-md-flex"><a href="<?= SITE_URL ?>">Home</a><a href="<?= SITE_URL ?>/templates_browse.php">Templates</a><a href="<?= SITE_URL ?>/about.php">About</a><a href="<?= SITE_URL ?>/contact.php" class="active">Contact</a></div>
</div></nav>
<div class="content">
    <h1><i class="fas fa-envelope me-2" style="color:#6366f1"></i>Contact Us</h1>
    <p class="sub">Have questions or feedback? We'd love to hear from you.</p>
    <form method="POST">
        <div class="fg"><label>Full Name</label><input type="text" name="name" required placeholder="Your name"></div>
        <div class="fg"><label>Email</label><input type="email" name="email" required placeholder="your@email.com"></div>
        <div class="fg"><label>Subject</label><input type="text" name="subject" placeholder="How can we help?"></div>
        <div class="fg"><label>Message</label><textarea name="message" required placeholder="Write your message here..."></textarea></div>
        <button type="submit" class="btn-send"><i class="fas fa-paper-plane"></i> Send Message</button>
    </form>
    <div class="contact-info">
        <div class="ci"><i class="fas fa-envelope"></i><h5>Email</h5><p>info@cvmarkerpro.com</p></div>
        <div class="ci"><i class="fas fa-phone"></i><h5>Phone</h5><p>+92 300 1234567</p></div>
        <div class="ci"><i class="fas fa-map-marker-alt"></i><h5>Location</h5><p>Lahore, Pakistan</p></div>
    </div>
</div>
<footer class="site-footer"><p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="includes/common.js"></script>
<?php if($flash): ?><script>document.addEventListener('DOMContentLoaded',()=>showToast('<?= addslashes($flash['message']) ?>','<?= $flash['type'] ?>'));</script><?php endif; ?>
</body>
</html>
