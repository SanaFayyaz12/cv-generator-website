<?php
require_once dirname(__DIR__, 2) . '/includes/config.php';
requireEmployer();
$db = getDB();
$pageTitle = $pageTitle ?? 'Employer Panel';
$empName = $_SESSION['employer_name'] ?? 'Employer';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($pageTitle) ?> - CV Craft</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
body{background:#0f172a;color:#e2e8f0;font-family:Inter,Arial,sans-serif}.sidebar{width:250px;min-height:100vh;background:#111827;position:fixed;left:0;top:0;padding:1.2rem;border-right:1px solid rgba(255,255,255,.08)}.brand{font-weight:800;color:#fff;font-size:1.2rem;margin-bottom:1.5rem}.nav-link{color:#94a3b8;border-radius:10px;margin:.2rem 0}.nav-link:hover,.nav-link.active{background:#2563eb;color:#fff}.main{margin-left:250px;padding:1.5rem}.card{background:#1e293b;border:1px solid rgba(255,255,255,.08);border-radius:16px;color:#e2e8f0}.form-control,.form-select{background:#0f172a;border-color:#334155;color:#e2e8f0}.form-control:focus,.form-select:focus{background:#0f172a;color:#fff;border-color:#3b82f6;box-shadow:none}.table{--bs-table-bg:transparent;--bs-table-color:#e2e8f0;--bs-table-border-color:#334155}.muted{color:#94a3b8}@media(max-width:800px){.sidebar{position:static;width:100%;min-height:auto}.main{margin-left:0}}
</style>
</head>
<body>
<div class="sidebar">
 <div class="brand"><i class="fa-solid fa-building me-2 text-primary"></i>Employer</div>
 <div class="muted small mb-3"><?= htmlspecialchars($empName) ?></div>
 <a class="nav-link" href="<?= SITE_URL ?>/employer/dashboard.php"><i class="fa-solid fa-chart-line me-2"></i>Dashboard</a>
 <a class="nav-link" href="<?= SITE_URL ?>/employer/jobs.php"><i class="fa-solid fa-briefcase me-2"></i>Manage Jobs</a>
 <a class="nav-link" href="<?= SITE_URL ?>/employer/applicants.php"><i class="fa-solid fa-users me-2"></i>Applicants</a>
 <a class="nav-link" href="<?= SITE_URL ?>/candidate/jobs.php"><i class="fa-solid fa-eye me-2"></i>Public Jobs</a>
 <a class="nav-link text-danger" href="<?= SITE_URL ?>/employer/logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Logout</a>
</div>
<main class="main">
<?php $flash=getFlash(); if($flash): ?><div class="alert alert-<?= htmlspecialchars($flash['type']) ?>"><?= htmlspecialchars($flash['message']) ?></div><?php endif; ?>