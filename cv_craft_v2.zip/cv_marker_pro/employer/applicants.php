<?php
require_once dirname(__DIR__) . '/includes/config.php';
header('Location: ' . SITE_URL);
exit;
