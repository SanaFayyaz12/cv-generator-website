<?php require_once 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CV Craft — Build a Professional CV in Minutes</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Sora:wght@700;800;900&display=swap" rel="stylesheet">
<style>
:root{--primary:#6366f1;--primary-dark:#4f46e5;--accent:#10b981;--accent-dark:#059669;--dark:#0a0f1e;--card:#1e293b;--border:rgba(255,255,255,0.07);}
*{margin:0;padding:0;box-sizing:border-box;}
html{scroll-behavior:smooth;}
body{font-family:'Inter',sans-serif;background:var(--dark);color:#e2e8f0;overflow-x:hidden;}

/* NAVBAR */
.navbar-main{position:fixed;top:0;left:0;right:0;z-index:1000;padding:1rem 0;transition:all 0.3s;}
.navbar-main.scrolled{background:rgba(10,15,30,0.96);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);padding:0.65rem 0;}
.brand{display:flex;align-items:center;gap:0.6rem;text-decoration:none;}
.brand-box{width:36px;height:36px;background:linear-gradient(135deg,var(--primary),#8b5cf6);border-radius:10px;display:flex;align-items:center;justify-content:center;}
.brand-txt{font-family:'Sora',sans-serif;font-size:1.15rem;font-weight:800;color:#f1f5f9;}
.brand-txt span{color:var(--primary);}
.nav-a{color:#94a3b8;font-size:0.875rem;font-weight:500;text-decoration:none;padding:0.4rem 0.75rem;transition:color 0.2s;border-radius:6px;}
.nav-a:hover{color:#f1f5f9;}
.btn-login{background:transparent;border:1px solid rgba(255,255,255,0.15);color:#e2e8f0;padding:0.42rem 1.1rem;border-radius:8px;font-size:0.85rem;font-weight:600;text-decoration:none;transition:all 0.2s;}
.btn-login:hover{background:rgba(255,255,255,0.07);color:#fff;}
.btn-signup{background:linear-gradient(135deg,var(--primary),#8b5cf6);color:#fff;padding:0.42rem 1.2rem;border-radius:8px;font-size:0.85rem;font-weight:700;text-decoration:none;transition:all 0.2s;}
.btn-signup:hover{transform:translateY(-1px);box-shadow:0 4px 16px rgba(99,102,241,0.4);color:#fff;}

/* HERO */
.hero{min-height:100vh;display:flex;align-items:center;padding:7rem 0 4rem;position:relative;overflow:hidden;}
.hero-bg{position:absolute;inset:0;background:radial-gradient(ellipse at 20% 50%,rgba(99,102,241,0.12) 0%,transparent 55%),radial-gradient(ellipse at 80% 20%,rgba(139,92,246,0.09) 0%,transparent 50%);}
.hero-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(99,102,241,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(99,102,241,0.04) 1px,transparent 1px);background-size:44px 44px;mask-image:radial-gradient(ellipse at center,black 30%,transparent 75%);}
.hero-badge{display:inline-flex;align-items:center;gap:0.5rem;background:rgba(99,102,241,0.1);border:1px solid rgba(99,102,241,0.25);color:#a5b4fc;padding:0.38rem 1rem;border-radius:50px;font-size:0.77rem;font-weight:700;letter-spacing:0.04em;text-transform:uppercase;margin-bottom:1.4rem;}
.live-dot{width:6px;height:6px;background:#6366f1;border-radius:50%;animation:blink 2s infinite;}
@keyframes blink{0%,100%{opacity:1}50%{opacity:0.25}}
.hero-title{font-family:'Sora',sans-serif;font-size:clamp(2.8rem,5.5vw,4.6rem);font-weight:900;line-height:1.05;letter-spacing:-0.02em;margin-bottom:1.4rem;}
.hero-title .white{color:#f1f5f9;}
.hero-title .grad{background:linear-gradient(135deg,#6366f1,#a78bfa,#34d399);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.hero-sub{color:#94a3b8;font-size:1.05rem;line-height:1.8;max-width:520px;margin-bottom:2rem;}
.hero-btns{display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:2.5rem;}
.btn-hero-primary{background:linear-gradient(135deg,var(--primary),#8b5cf6);color:#fff;padding:0.85rem 2.2rem;border-radius:12px;font-weight:700;font-size:0.95rem;text-decoration:none;transition:all 0.3s;display:inline-flex;align-items:center;gap:0.5rem;}
.btn-hero-primary:hover{transform:translateY(-2px);box-shadow:0 12px 28px rgba(99,102,241,0.4);color:#fff;}
.btn-hero-outline{background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.12);color:#e2e8f0;padding:0.85rem 2.2rem;border-radius:12px;font-weight:600;font-size:0.95rem;text-decoration:none;transition:all 0.3s;display:inline-flex;align-items:center;gap:0.5rem;}
.btn-hero-outline:hover{background:rgba(255,255,255,0.09);color:#fff;}
.trust-badges{display:flex;gap:1.5rem;flex-wrap:wrap;align-items:center;}
.trust-item{display:flex;align-items:center;gap:0.5rem;color:#64748b;font-size:0.82rem;font-weight:500;}
.trust-item i{color:#f59e0b;}

/* Floating Cards */
.hero-visual{position:relative;height:480px;}
.fcard{position:absolute;background:rgba(30,41,59,0.92);border:1px solid rgba(255,255,255,0.09);border-radius:16px;backdrop-filter:blur(20px);padding:1.2rem 1.4rem;box-shadow:0 20px 40px rgba(0,0,0,0.35);}
.fc1{top:5%;left:0;width:270px;animation:flt1 6s ease-in-out infinite;}
.fc2{top:38%;right:0;width:195px;animation:flt2 5s ease-in-out infinite;}
.fc3{bottom:5%;left:10%;width:245px;animation:flt1 7s ease-in-out infinite 1s;}
@keyframes flt1{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
@keyframes flt2{0%,100%{transform:translateY(0)}50%{transform:translateY(10px)}}

/* SECTIONS */
section{padding:5rem 0;}
.sec-label{font-size:0.73rem;font-weight:700;color:var(--primary);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.6rem;}
.sec-title{font-family:'Sora',sans-serif;font-size:2.1rem;font-weight:800;color:#f1f5f9;margin-bottom:0.9rem;}
.sec-desc{color:#64748b;font-size:0.95rem;line-height:1.7;max-width:500px;margin:0 auto;}

/* TEMPLATE CARDS */
.tpl-filter{display:flex;gap:0.5rem;flex-wrap:wrap;justify-content:center;margin-bottom:2.5rem;}
.tpl-btn{background:rgba(255,255,255,0.04);border:1px solid var(--border);color:#94a3b8;padding:0.45rem 1.1rem;border-radius:20px;font-size:0.82rem;font-weight:600;cursor:pointer;transition:all 0.2s;}
.tpl-btn:hover,.tpl-btn.active{background:var(--primary);border-color:var(--primary);color:#fff;}
.template-card{background:var(--card);border:1px solid var(--border);border-radius:18px;overflow:hidden;transition:all 0.3s;height:100%;}
.template-card:hover{transform:translateY(-6px);border-color:rgba(99,102,241,0.35);box-shadow:0 20px 40px rgba(0,0,0,0.35);}
.tpl-preview{aspect-ratio:3/4;background:#f0f4f8;position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;cursor:pointer;}
.tpl-preview:hover .tpl-hover-overlay{opacity:1;}
.tpl-hover-overlay{position:absolute;inset:0;background:rgba(99,102,241,0.88);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0.6rem;opacity:0;transition:opacity 0.3s;z-index:5;}
.tpl-hover-overlay a{background:#fff;color:#4f46e5;padding:0.5rem 1.4rem;border-radius:8px;font-size:0.82rem;font-weight:700;text-decoration:none;transition:all 0.2s;width:140px;text-align:center;}
.tpl-hover-overlay a:hover{background:#f0f0ff;}
.tpl-hover-overlay a.outline{background:transparent;border:1px solid rgba(255,255,255,0.5);color:#fff;}
.tpl-hover-overlay a.outline:hover{background:rgba(255,255,255,0.15);}
/* Realistic CV mocks */
.cv-real{width:82%;background:#fff;box-shadow:0 6px 24px rgba(0,0,0,0.18);font-family:Arial,sans-serif;overflow:hidden;}
.tpl-badges{position:absolute;top:0.6rem;left:0.6rem;display:flex;gap:0.3rem;flex-wrap:wrap;z-index:4;}
.tpl-badge{padding:0.2rem 0.5rem;border-radius:4px;font-size:0.65rem;font-weight:700;}
.badge-popular{background:#f59e0b;color:#000;}
.badge-ats{background:#10b981;color:#fff;}
.badge-new{background:#6366f1;color:#fff;}
.tpl-body{padding:1.2rem;}
.tpl-name{font-family:'Sora',sans-serif;font-size:0.95rem;font-weight:700;color:#f1f5f9;margin-bottom:0.3rem;}
.tpl-desc{font-size:0.8rem;color:#64748b;margin-bottom:0.9rem;line-height:1.5;}
.tpl-tags{display:flex;gap:0.3rem;flex-wrap:wrap;margin-bottom:1rem;}
.tpl-tag{background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#94a3b8;padding:0.18rem 0.55rem;border-radius:4px;font-size:0.7rem;}
.tpl-actions{display:flex;gap:0.5rem;}
.btn-use{flex:1;background:linear-gradient(135deg,var(--primary),#8b5cf6);color:#fff;padding:0.5rem;border-radius:8px;font-size:0.8rem;font-weight:700;text-decoration:none;text-align:center;transition:all 0.2s;border:none;cursor:pointer;}
.btn-use:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(99,102,241,0.4);color:#fff;}
.btn-preview{background:rgba(255,255,255,0.05);border:1px solid var(--border);color:#94a3b8;padding:0.5rem 0.8rem;border-radius:8px;font-size:0.8rem;font-weight:600;text-decoration:none;text-align:center;transition:all 0.2s;cursor:pointer;}
.btn-preview:hover{background:rgba(255,255,255,0.09);color:#f1f5f9;}

/* FEATURES */
.feature-card{background:var(--card);border:1px solid var(--border);border-radius:18px;padding:2rem;height:100%;transition:all 0.3s;}
.feature-card:hover{transform:translateY(-5px);border-color:rgba(99,102,241,0.3);}
.f-icon{width:52px;height:52px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;margin-bottom:1.1rem;}
.feature-card h5{font-family:'Sora',sans-serif;font-size:1rem;font-weight:700;color:#f1f5f9;margin-bottom:0.5rem;}
.feature-card p{color:#64748b;font-size:0.875rem;line-height:1.7;margin:0;}

/* HOW IT WORKS */
.step-wrap{text-align:center;padding:1.5rem;}
.step-circle{width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#8b5cf6);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:1.1rem;display:flex;align-items:center;justify-content:center;margin:0 auto 1.2rem;box-shadow:0 8px 20px rgba(99,102,241,0.3);}
.step-wrap h5{font-family:'Sora',sans-serif;font-size:0.95rem;font-weight:700;color:#f1f5f9;margin-bottom:0.4rem;}
.step-wrap p{font-size:0.85rem;color:#64748b;line-height:1.6;}
.step-line{flex:1;height:1px;background:linear-gradient(90deg,var(--primary),#8b5cf6);opacity:0.25;margin-top:-2rem;}

/* AI FEATURES */
.ai-card{background:linear-gradient(135deg,rgba(99,102,241,0.08),rgba(139,92,246,0.06));border:1px solid rgba(99,102,241,0.2);border-radius:18px;padding:1.8rem;height:100%;transition:all 0.3s;}
.ai-card:hover{border-color:rgba(99,102,241,0.4);transform:translateY(-3px);}
.ai-card h5{font-family:'Sora',sans-serif;font-size:0.95rem;font-weight:700;color:#f1f5f9;margin-bottom:0.5rem;}
.ai-card p{font-size:0.85rem;color:#94a3b8;line-height:1.6;margin:0;}

/* PRICING */
.price-card{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:2.5rem;height:100%;transition:all 0.3s;position:relative;}
.price-card.popular{border-color:var(--primary);background:linear-gradient(135deg,rgba(99,102,241,0.08),rgba(139,92,246,0.05));}
.popular-badge{position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,var(--primary),#8b5cf6);color:#fff;padding:0.3rem 1.2rem;border-radius:20px;font-size:0.75rem;font-weight:700;white-space:nowrap;}
.price-name{font-size:0.85rem;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.8rem;}
.price-num{font-family:'Sora',sans-serif;font-size:2.8rem;font-weight:900;color:#f1f5f9;margin-bottom:0.3rem;}
.price-num span{font-size:1rem;font-weight:500;color:#64748b;}
.price-period{font-size:0.82rem;color:#64748b;margin-bottom:1.5rem;}
.price-features{list-style:none;padding:0;margin-bottom:2rem;}
.price-features li{display:flex;align-items:center;gap:0.6rem;color:#94a3b8;font-size:0.875rem;padding:0.4rem 0;border-bottom:1px solid var(--border);}
.price-features li:last-child{border:none;}
.price-features li i{font-size:0.75rem;color:var(--accent);flex-shrink:0;}
.price-features li.no i{color:#ef4444;}
.price-features li.no{color:#475569;}
.btn-price-primary{width:100%;padding:0.82rem;background:linear-gradient(135deg,var(--primary),#8b5cf6);color:#fff;border:none;border-radius:10px;font-weight:700;font-size:0.9rem;cursor:pointer;transition:all 0.2s;text-decoration:none;display:block;text-align:center;}
.btn-price-primary:hover{transform:translateY(-1px);box-shadow:0 8px 20px rgba(99,102,241,0.35);color:#fff;}
.btn-price-outline{width:100%;padding:0.82rem;background:transparent;color:#94a3b8;border:1px solid var(--border);border-radius:10px;font-weight:700;font-size:0.9rem;cursor:pointer;transition:all 0.2s;text-decoration:none;display:block;text-align:center;}
.btn-price-outline:hover{background:rgba(255,255,255,0.05);color:#f1f5f9;}

/* TESTIMONIALS */
.testi-card{background:var(--card);border:1px solid var(--border);border-radius:18px;padding:1.8rem;height:100%;transition:all 0.3s;}
.testi-card:hover{transform:translateY(-3px);border-color:rgba(99,102,241,0.25);}
.stars{color:#f59e0b;font-size:0.85rem;margin-bottom:0.9rem;}
.testi-text{color:#94a3b8;font-size:0.875rem;line-height:1.7;margin-bottom:1.2rem;font-style:italic;}
.testi-author{display:flex;align-items:center;gap:0.75rem;}
.testi-avatar{width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;color:#fff;}
.testi-name{font-weight:600;font-size:0.875rem;color:#f1f5f9;}
.testi-role{font-size:0.75rem;color:#64748b;}

/* EXAMPLES */
.example-card{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;transition:all 0.3s;}
.example-card:hover{transform:translateY(-4px);border-color:rgba(99,102,241,0.3);}
.example-preview{background:#f8fafc;aspect-ratio:3/4;display:flex;align-items:center;justify-content:center;position:relative;}
.example-overlay{position:absolute;inset:0;background:rgba(99,102,241,0.85);display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity 0.3s;}
.example-card:hover .example-overlay{opacity:1;}
.example-body{padding:1.2rem;}
.example-role{font-size:0.75rem;font-weight:700;color:var(--primary);text-transform:uppercase;letter-spacing:0.05em;margin-bottom:0.3rem;}
.example-name{font-family:'Sora',sans-serif;font-size:0.95rem;font-weight:700;color:#f1f5f9;}

/* CTA STRIP */
.cta-strip{background:linear-gradient(135deg,rgba(99,102,241,0.12),rgba(139,92,246,0.08));border-top:1px solid rgba(99,102,241,0.18);border-bottom:1px solid rgba(99,102,241,0.18);}

/* FOOTER */
footer{background:#070c18;border-top:1px solid var(--border);padding:4rem 0 2rem;}
.footer-brand-txt{font-family:'Sora',sans-serif;font-size:1.1rem;font-weight:800;color:#f1f5f9;}
.footer-desc{color:#475569;font-size:0.875rem;line-height:1.7;margin:0.8rem 0 1.2rem;}
.footer-social{display:flex;gap:0.6rem;}
.social-btn{width:34px;height:34px;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#64748b;font-size:0.85rem;text-decoration:none;transition:all 0.2s;}
.social-btn:hover{background:var(--primary);border-color:var(--primary);color:#fff;}
.footer-heading{font-size:0.75rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.09em;margin-bottom:1rem;}
.footer-links{list-style:none;padding:0;}
.footer-links li{margin-bottom:0.5rem;}
.footer-links a{color:#475569;text-decoration:none;font-size:0.875rem;transition:color 0.2s;}
.footer-links a:hover{color:#e2e8f0;}
.footer-bottom{border-top:1px solid var(--border);margin-top:2.5rem;padding-top:1.5rem;color:#334155;font-size:0.82rem;}

/* PORTAL CARDS */
.portal-card{border-radius:20px;padding:2.5rem;height:100%;position:relative;overflow:hidden;display:block;text-decoration:none;transition:transform 0.3s;}
.portal-card:hover{transform:translateY(-4px);}
.portal-admin{background:linear-gradient(135deg,#1e1b4b,#312e81);border:1px solid rgba(99,102,241,0.3);}
.portal-cand{background:linear-gradient(135deg,#064e3b,#065f46);border:1px solid rgba(16,185,129,0.3);}
.portal-card h4{font-family:'Sora',sans-serif;font-size:1.3rem;font-weight:800;color:#f1f5f9;margin-bottom:0.5rem;}
.portal-card p{color:rgba(255,255,255,0.55);font-size:0.875rem;margin-bottom:1.2rem;}
.portal-list{list-style:none;padding:0;margin-bottom:1.5rem;}
.portal-list li{color:rgba(255,255,255,0.65);font-size:0.83rem;padding:0.28rem 0;display:flex;align-items:center;gap:0.5rem;}
.portal-list li i{font-size:0.6rem;color:#10b981;}
.portal-link{display:inline-flex;align-items:center;gap:0.5rem;padding:0.65rem 1.4rem;border-radius:10px;font-size:0.875rem;font-weight:700;text-decoration:none;transition:all 0.2s;}

@media(max-width:991px){.hero-visual{display:none!important;}.hero{text-align:center;}.hero-btns,.trust-badges{justify-content:center;}.hero-sub{margin:0 auto 2rem;}}
@media(max-width:576px){.hero-title{font-size:2.3rem;}.sec-title{font-size:1.6rem;}}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar-main" id="mainNav">
  <div class="container">
    <div class="d-flex align-items-center justify-content-between w-100">
      <a class="brand" href="<?= SITE_URL ?>">
        <div class="brand-box"><i class="fas fa-file-alt" style="color:#fff;font-size:0.95rem"></i></div>
        <span class="brand-txt">CV <span>Craft</span></span>
      </a>
      <div class="d-none d-lg-flex align-items-center gap-1">
        <a href="#templates" class="nav-a">Templates</a>
        <a href="templates_browse.php" class="nav-a">Templates</a>
    <a href="#features" class="nav-a">Features</a>
        <a href="#how-it-works" class="nav-a">How It Works</a>
        <a href="#examples" class="nav-a">Examples</a>
        <a href="#pricing" class="nav-a">Pricing</a>
      </div>
      <div class="d-flex align-items-center gap-2">
        <a href="<?= SITE_URL ?>/login.php" class="btn-login d-none d-md-inline">Login</a>
        <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-signup">Sign Up Free</a>
        <a href="<?= SITE_URL ?>/admin/dashboard.php" class="btn-login d-none d-md-inline" style="border-color:rgba(99,102,241,0.4);color:#a5b4fc"><i class="fas fa-shield-alt me-1"></i>Admin</a>
      </div>
    </div>
  </div>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-grid"></div>
  <div class="container position-relative">
    <div class="row align-items-center g-5">
      <div class="col-lg-6">
        <div class="hero-badge"><span class="live-dot"></span> AI-Powered CV Platform</div>
        <h1 class="hero-title">
          <span class="white">Build a Professional</span><br>
          <span class="grad">CV in Minutes</span>
        </h1>
        <p class="hero-sub">Fast, easy, and ATS-friendly. Create a stunning CV with AI-powered writing assistance, choose from 15+ templates, and download instantly.</p>
        <div class="hero-btns">
          <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-hero-primary"><i class="fas fa-rocket"></i> Create CV for Free</a>
          <a href="#templates" class="btn-hero-outline"><i class="fas fa-th-large"></i> View Templates</a>
        </div>
        <div class="trust-badges">
          <div class="trust-item"><i class="fas fa-users"></i> 1M+ users</div>
          <div class="trust-item"><i class="fas fa-star"></i> 4.8★ rating</div>
          <div class="trust-item"><i class="fas fa-shield-alt" style="color:#10b981"></i> Trusted by professionals</div>
        </div>
      </div>
      <div class="col-lg-6 d-none d-lg-block">
        <div class="hero-visual">
          <!-- Card 1: CV Score -->
          <div class="fcard fc1">
            <div class="d-flex align-items-center gap-2 mb-2">
              <div style="width:30px;height:30px;border-radius:8px;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center"><i class="fas fa-user-tie" style="color:#fff;font-size:0.7rem"></i></div>
              <div><div style="font-size:0.82rem;font-weight:700;color:#f1f5f9">Ali Hassan</div><div style="font-size:0.68rem;color:#64748b">PHP Developer</div></div>
            </div>
            <div style="font-size:0.72rem;color:#94a3b8;margin-bottom:0.5rem">ATS Score</div>
            <?php foreach(['Keywords Match'=>88,'Formatting'=>95,'Readability'=>79] as $k=>$v): ?>
            <div class="d-flex justify-content-between mb-1"><span style="font-size:0.68rem;color:#94a3b8"><?=$k?></span><span style="font-size:0.68rem;font-weight:700;color:#10b981"><?=$v?>%</span></div>
            <div style="height:3px;background:rgba(255,255,255,0.06);border-radius:2px;margin-bottom:0.5rem"><div style="width:<?=$v?>%;height:100%;background:linear-gradient(90deg,#6366f1,#10b981);border-radius:2px"></div></div>
            <?php endforeach; ?>
          </div>
          <!-- Card 2: Final Score -->
          <div class="fcard fc2" style="text-align:center">
            <div style="font-size:0.68rem;color:#64748b;margin-bottom:0.3rem">CV Score</div>
            <div style="font-family:'Sora',sans-serif;font-size:2.4rem;font-weight:900;background:linear-gradient(135deg,#10b981,#34d399);-webkit-background-clip:text;-webkit-text-fill-color:transparent">87</div>
            <div style="font-size:0.68rem;color:#64748b">/100 ATS Score</div>
            <div style="margin-top:0.6rem;background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.25);border-radius:6px;padding:0.3rem;font-size:0.7rem;font-weight:700;color:#10b981">✓ Excellent</div>
          </div>
          <!-- Card 3: Activity -->
          <div class="fcard fc3">
            <div style="font-size:0.75rem;font-weight:700;color:#f1f5f9;margin-bottom:0.6rem"><i class="fas fa-magic" style="color:#8b5cf6;margin-right:0.4rem"></i>AI Suggestions</div>
            <?php foreach(['Add quantified achievements','Include more keywords','Optimize summary section'] as $s): ?>
            <div class="d-flex align-items-center gap-2 mb-1">
              <div style="width:5px;height:5px;border-radius:50%;background:#6366f1;flex-shrink:0"></div>
              <div style="font-size:0.7rem;color:#94a3b8"><?=$s?></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- TEMPLATES -->
<section id="templates" style="background:rgba(255,255,255,0.01)">
  <div class="container">
    <div class="text-center mb-2">
      <div class="sec-label">Templates</div>
      <h2 class="sec-title">Choose Your Perfect Template</h2>
      <p class="sec-desc">15+ professional templates designed for every industry and career level.</p>
    </div>
    <div class="tpl-filter mt-4">
      <?php foreach(['All','ATS-Friendly','Modern','Creative','Academic','Tech/Dev'] as $f): ?>
      <button class="tpl-btn <?= $f==='All'?'active':'' ?>" onclick="filterTpl(this,'<?=$f?>')"><?=$f?></button>
      <?php endforeach; ?>
    </div>
    <div class="row g-4" id="tplGrid">

      <!-- Template 1: Classic Professional (ATS) -->
      <div class="col-sm-6 col-lg-4 tpl-item" data-cat="ATS-Friendly">
        <div class="template-card">
          <div class="tpl-preview" style="background:#e8edf2">
            <div class="tpl-badges"><span class="tpl-badge badge-popular">★ Popular</span><span class="tpl-badge badge-ats">ATS</span></div>
            <div class="cv-real">
              <div style="background:#1e293b;padding:10px 12px;color:#fff">
                <div style="font-size:11px;font-weight:bold;letter-spacing:1px">JOHN JAMES DOE</div>
                <div style="font-size:6px;opacity:0.75;margin-top:1px">Branding &amp; Media Specialist</div>
                <div style="font-size:5.5px;opacity:0.55;margin-top:2px">john@email.com · +1 234 5678 · New York, USA</div>
              </div>
              <div style="padding:8px 12px;font-size:5.5px;color:#1e293b">
                <div style="font-size:6px;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid #1e293b;padding-bottom:2px;margin-bottom:4px">Profile</div>
                <div style="color:#4b5563;line-height:1.4;margin-bottom:6px">With over 10 years experience in advertising and branding fields, I help companies grow through strategic communication and creative direction.</div>
                <div style="font-size:6px;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid #1e293b;padding-bottom:2px;margin-bottom:4px">Experience</div>
                <?php foreach([['Media Director','Company B','2005–2017'],['Design Consultant','Company A','2002–2004'],['Brand Strategist','Company Z','2000–2002']] as [$role,$co,$yr]): ?>
                <div style="margin-bottom:4px"><div style="display:flex;justify-content:space-between"><strong style="font-size:6px"><?=$role?></strong><span style="font-size:5px;color:#6b7280"><?=$yr?></span></div><div style="color:#6b7280;font-size:5px"><?=$co?></div><div style="color:#4b5563;font-size:5px;margin-top:1px">• Led strategic branding campaigns</div></div>
                <?php endforeach; ?>
                <div style="font-size:6px;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid #1e293b;padding-bottom:2px;margin:5px 0 4px">Education</div>
                <div style="margin-bottom:3px"><div style="font-weight:bold;font-size:6px">Strategic Branding</div><div style="color:#6b7280;font-size:5px">London Business School · 2005–2008</div></div>
              </div>
            </div>
            <div class="tpl-hover-overlay">
              <a href="<?= SITE_URL ?>/candidate/register.php">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template1_modern.html" target="_blank" class="outline"><i class="fas fa-eye me-1"></i> Preview</a>
            </div>
          </div>
          <div class="tpl-body">
            <div class="tpl-name">Classic Professional</div>
            <div class="tpl-desc">Clean single-column layout, perfect for corporate and executive roles.</div>
            <div class="tpl-tags"><span class="tpl-tag">ATS-Friendly</span><span class="tpl-tag">Popular</span><span class="tpl-tag">Corporate</span></div>
            <div class="tpl-actions">
              <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-use">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template1_modern.html" target="_blank" class="btn-preview"><i class="fas fa-eye"></i> Preview</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Template 2: Modern Two-Column -->
      <div class="col-sm-6 col-lg-4 tpl-item" data-cat="Modern">
        <div class="template-card">
          <div class="tpl-preview" style="background:#e2e8f0">
            <div class="tpl-badges"><span class="tpl-badge badge-popular">★ Popular</span></div>
            <div class="cv-real" style="display:flex">
              <div style="width:38%;background:#1a3a5c;padding:8px;color:#fff;min-height:200px">
                <div style="width:32px;height:32px;background:rgba(255,255,255,0.2);border-radius:50%;margin:0 auto 5px;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:9px">JD</div>
                <div style="text-align:center;font-size:6.5px;font-weight:bold;margin-bottom:2px">JOHN JAMES DOE</div>
                <div style="text-align:center;font-size:5px;opacity:0.7;margin-bottom:8px">Media Specialist</div>
                <div style="font-size:5.5px;font-weight:bold;border-bottom:1px solid rgba(255,255,255,0.2);padding-bottom:1px;margin-bottom:3px">SKILLS</div>
                <?php foreach(['Branding','Typography','Marketing','Adobe CC','Strategy'] as $s): ?>
                <div style="font-size:5px;margin-bottom:2px">▸ <?=$s?></div>
                <?php endforeach; ?>
                <div style="font-size:5.5px;font-weight:bold;border-bottom:1px solid rgba(255,255,255,0.2);padding-bottom:1px;margin:5px 0 3px">LANGUAGES</div>
                <div style="font-size:5px">English (Native)</div>
                <div style="font-size:5px">French (B2)</div>
                <div style="font-size:5.5px;font-weight:bold;border-bottom:1px solid rgba(255,255,255,0.2);padding-bottom:1px;margin:5px 0 3px">CONTACT</div>
                <div style="font-size:4.5px;line-height:1.6;word-break:break-all">john@email.com<br>+1 234 567 8900<br>New York, USA</div>
              </div>
              <div style="flex:1;padding:8px;font-size:5.5px;color:#1e293b">
                <div style="font-size:10px;font-weight:bold;color:#1a3a5c;margin-bottom:1px">JOHN DOE</div>
                <div style="font-size:5.5px;color:#4b5563;margin-bottom:5px;border-bottom:1px solid #e2e8f0;padding-bottom:3px">Media Director &amp; Brand Strategist</div>
                <div style="font-size:5.5px;font-weight:bold;color:#1a3a5c;margin-bottom:2px">EXPERIENCE</div>
                <?php foreach([['Media Director','Company B','2005–Present'],['Design Consultant','Firm A','2002–2004']] as [$r,$c,$y]): ?>
                <div style="margin-bottom:4px"><div style="font-weight:bold;font-size:5.5px"><?=$r?></div><div style="color:#1a3a5c;font-size:5px"><?=$c?> · <?=$y?></div><div style="color:#6b7280;font-size:4.5px;margin-top:1px">• Led cross-functional brand campaigns</div></div>
                <?php endforeach; ?>
                <div style="font-size:5.5px;font-weight:bold;color:#1a3a5c;margin:4px 0 2px">EDUCATION</div>
                <div style="font-weight:bold;font-size:5.5px">BSc Communication Design</div>
                <div style="color:#6b7280;font-size:5px">London Arts University · 2005</div>
              </div>
            </div>
            <div class="tpl-hover-overlay">
              <a href="<?= SITE_URL ?>/candidate/register.php">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template2_minimal.html" target="_blank" class="outline"><i class="fas fa-eye me-1"></i> Preview</a>
            </div>
          </div>
          <div class="tpl-body">
            <div class="tpl-name">Modern Two-Column</div>
            <div class="tpl-desc">Elegant two-column layout with sidebar skills and contact info.</div>
            <div class="tpl-tags"><span class="tpl-tag">Modern</span><span class="tpl-tag">Popular</span><span class="tpl-tag">Two-Column</span></div>
            <div class="tpl-actions">
              <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-use">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template2_minimal.html" target="_blank" class="btn-preview"><i class="fas fa-eye"></i> Preview</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Template 3: Creative Designer -->
      <div class="col-sm-6 col-lg-4 tpl-item" data-cat="Creative">
        <div class="template-card">
          <div class="tpl-preview" style="background:#f3e8ff">
            <div class="tpl-badges"><span class="tpl-badge badge-new">New</span></div>
            <div class="cv-real">
              <div style="background:linear-gradient(135deg,#7c3aed,#4f46e5);padding:10px 12px;color:#fff;display:flex;align-items:center;gap:8px">
                <div style="width:32px;height:32px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:bold;flex-shrink:0">JD</div>
                <div><div style="font-size:9px;font-weight:bold">JOHN JAMES DOE</div><div style="font-size:5.5px;opacity:0.8;margin-top:1px">Creative Director &amp; UI/UX Designer</div></div>
              </div>
              <div style="padding:8px 12px;font-size:5.5px;color:#1e293b">
                <div style="display:flex;gap:4px;margin-bottom:4px">
                  <span style="background:#7c3aed;color:#fff;padding:1px 5px;border-radius:10px;font-size:4.5px;font-weight:bold">EXPERIENCE</span>
                </div>
                <?php foreach([['Design Lead','StudioX','2021–Present'],['UX Designer','PixelCo','2018–2021'],['Jr. Designer','CreativeHub','2016–2018']] as [$r,$c,$y]): ?>
                <div style="margin-bottom:4px;padding-left:6px;border-left:2px solid #7c3aed"><div style="font-weight:bold;font-size:6px"><?=$r?></div><div style="color:#7c3aed;font-size:5px"><?=$c?> · <?=$y?></div><div style="color:#4b5563;font-size:5px">• Led design system creation</div></div>
                <?php endforeach; ?>
                <div style="display:flex;gap:4px;margin:4px 0">
                  <span style="background:#7c3aed;color:#fff;padding:1px 5px;border-radius:10px;font-size:4.5px;font-weight:bold">SKILLS</span>
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:3px">
                  <?php foreach(['Figma','Sketch','React','Tailwind','Branding'] as $s): ?>
                  <span style="background:rgba(124,58,237,0.1);border:1px solid rgba(124,58,237,0.3);color:#6d28d9;padding:1px 5px;border-radius:8px;font-size:4.5px"><?=$s?></span>
                  <?php endforeach; ?>
                </div>
              </div>
            </div>
            <div class="tpl-hover-overlay">
              <a href="<?= SITE_URL ?>/candidate/register.php">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template3_glassmorphism.html" target="_blank" class="outline"><i class="fas fa-eye me-1"></i> Preview</a>
            </div>
          </div>
          <div class="tpl-body">
            <div class="tpl-name">Creative Designer</div>
            <div class="tpl-desc">Bold gradient header with accent colors — perfect for creative fields.</div>
            <div class="tpl-tags"><span class="tpl-tag">Creative</span><span class="tpl-tag">New</span><span class="tpl-tag">Designer</span></div>
            <div class="tpl-actions">
              <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-use">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template3_glassmorphism.html" target="_blank" class="btn-preview"><i class="fas fa-eye"></i> Preview</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Template 4: Tech Developer -->
      <div class="col-sm-6 col-lg-4 tpl-item" data-cat="Tech/Dev">
        <div class="template-card">
          <div class="tpl-preview" style="background:#e0f2fe">
            <div class="tpl-badges"><span class="tpl-badge badge-ats">ATS</span></div>
            <div class="cv-real">
              <div style="background:#0f172a;padding:10px 12px;color:#fff;border-bottom:3px solid #3b82f6">
                <div style="font-size:9.5px;font-weight:bold;letter-spacing:0.5px">John Doe</div>
                <div style="color:#3b82f6;font-size:5.5px;margin-top:1px">Full Stack Developer</div>
                <div style="font-size:5px;color:#94a3b8;margin-top:2px">github.com/johndoe · john@dev.io · Lahore, PK</div>
              </div>
              <div style="padding:8px 12px;font-size:5.5px;color:#1e293b">
                <div style="font-size:5.5px;font-weight:bold;color:#0f172a;border-left:2px solid #3b82f6;padding-left:4px;margin-bottom:3px">TECHNICAL SKILLS</div>
                <div style="display:flex;flex-wrap:wrap;gap:2px;margin-bottom:5px">
                  <?php foreach(['PHP','Laravel','React','Node.js','MySQL','Docker','AWS','Git'] as $s): ?>
                  <span style="background:#eff6ff;border:1px solid #bfdbfe;color:#1d4ed8;padding:1px 4px;border-radius:3px;font-size:4.5px"><?=$s?></span>
                  <?php endforeach; ?>
                </div>
                <div style="font-size:5.5px;font-weight:bold;color:#0f172a;border-left:2px solid #3b82f6;padding-left:4px;margin-bottom:3px">EXPERIENCE</div>
                <?php foreach([['Senior Developer','TechCorp','2021–Present'],['Backend Dev','StartupXYZ','2019–2021']] as [$r,$c,$y]): ?>
                <div style="margin-bottom:4px"><div style="font-weight:bold;font-size:5.5px"><?=$r?> — <?=$c?></div><div style="color:#6b7280;font-size:5px"><?=$y?></div><div style="color:#4b5563;font-size:5px;margin-top:1px">• Built REST APIs serving 500K+ users/day</div></div>
                <?php endforeach; ?>
                <div style="font-size:5.5px;font-weight:bold;color:#0f172a;border-left:2px solid #3b82f6;padding-left:4px;margin:4px 0 3px">EDUCATION</div>
                <div style="font-size:5.5px;font-weight:bold">BS Computer Science</div>
                <div style="color:#6b7280;font-size:5px">FAST University · 2019 · 3.8 GPA</div>
              </div>
            </div>
            <div class="tpl-hover-overlay">
              <a href="<?= SITE_URL ?>/candidate/register.php">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template1_modern.html" target="_blank" class="outline"><i class="fas fa-eye me-1"></i> Preview</a>
            </div>
          </div>
          <div class="tpl-body">
            <div class="tpl-name">Tech Developer</div>
            <div class="tpl-desc">Code-inspired layout with skill badges — ideal for developers and engineers.</div>
            <div class="tpl-tags"><span class="tpl-tag">Tech/Dev</span><span class="tpl-tag">ATS-Friendly</span><span class="tpl-tag">Developer</span></div>
            <div class="tpl-actions">
              <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-use">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template1_modern.html" target="_blank" class="btn-preview"><i class="fas fa-eye"></i> Preview</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Template 5: Academic Research -->
      <div class="col-sm-6 col-lg-4 tpl-item" data-cat="Academic">
        <div class="template-card">
          <div class="tpl-preview" style="background:#fef9e7">
            <div class="tpl-badges"></div>
            <div class="cv-real">
              <div style="padding:10px 12px;border-bottom:2.5px double #92400e;text-align:center">
                <div style="font-size:11px;font-weight:bold;letter-spacing:0.5px;color:#1e293b">JOHN JAMES DOE, PhD</div>
                <div style="font-size:5.5px;color:#4b5563;margin-top:2px">Associate Professor · Computer Science</div>
                <div style="font-size:5px;color:#6b7280;margin-top:1px">john@university.edu · +1 234 5678 · New York, USA</div>
              </div>
              <div style="padding:7px 12px;font-size:5.5px;color:#1e293b">
                <div style="font-size:5.5px;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;color:#92400e;margin-bottom:2px">Research Interests</div>
                <div style="color:#4b5563;font-size:5px;margin-bottom:4px">Machine Learning · NLP · Computer Vision · Deep Learning</div>
                <div style="font-size:5.5px;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;color:#92400e;margin-bottom:2px">Publications</div>
                <?php foreach(['Deep Learning in Medical Imaging (2023)','Efficient NLP Transformers (2022)','Survey on Federated Learning (2021)'] as $p): ?>
                <div style="font-size:5px;color:#4b5563;margin-bottom:2px">• <?=$p?></div>
                <?php endforeach; ?>
                <div style="font-size:5.5px;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;color:#92400e;margin:4px 0 2px">Education</div>
                <div style="margin-bottom:2px"><div style="font-weight:bold;font-size:5.5px">PhD Computer Science</div><div style="color:#6b7280;font-size:5px">MIT · 2018</div></div>
                <div><div style="font-weight:bold;font-size:5.5px">MS Artificial Intelligence</div><div style="color:#6b7280;font-size:5px">Stanford · 2014</div></div>
              </div>
            </div>
            <div class="tpl-hover-overlay">
              <a href="<?= SITE_URL ?>/candidate/register.php">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template2_minimal.html" target="_blank" class="outline"><i class="fas fa-eye me-1"></i> Preview</a>
            </div>
          </div>
          <div class="tpl-body">
            <div class="tpl-name">Academic Research</div>
            <div class="tpl-desc">Comprehensive format with publications, research and academic credentials.</div>
            <div class="tpl-tags"><span class="tpl-tag">Academic</span><span class="tpl-tag">Research</span><span class="tpl-tag">PhD</span></div>
            <div class="tpl-actions">
              <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-use">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template2_minimal.html" target="_blank" class="btn-preview"><i class="fas fa-eye"></i> Preview</a>
            </div>
          </div>
        </div>
      </div>

      <!-- Template 6: Executive Elite -->
      <div class="col-sm-6 col-lg-4 tpl-item" data-cat="Modern">
        <div class="template-card">
          <div class="tpl-preview" style="background:#ede9fe">
            <div class="tpl-badges"><span class="tpl-badge badge-popular">★ Popular</span></div>
            <div class="cv-real">
              <div style="background:linear-gradient(135deg,#1e1b4b,#312e81);padding:12px;color:#fff;display:flex;gap:8px;align-items:flex-start">
                <div style="width:36px;height:40px;background:rgba(255,255,255,0.15);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:bold;flex-shrink:0;border:1px solid rgba(255,255,255,0.25)">JD</div>
                <div><div style="font-size:9.5px;font-weight:bold;letter-spacing:0.5px">JOHN DOE</div><div style="font-size:5.5px;color:#c4b5fd;margin-top:1px">Chief Executive Officer</div><div style="font-size:5px;opacity:0.6;margin-top:2px">john@executive.com · New York</div></div>
              </div>
              <div style="padding:8px 12px;font-size:5.5px;color:#1e293b">
                <div style="background:rgba(99,102,241,0.08);border-left:3px solid #6366f1;padding:4px 7px;border-radius:0 6px 6px 0;margin-bottom:5px;font-size:5px;color:#374151;font-style:italic">Senior executive with 20+ years leading Fortune 500 companies. Expertise in strategy, M&amp;A, and global operations.</div>
                <div style="font-size:5.5px;font-weight:bold;color:#312e81;text-transform:uppercase;letter-spacing:0.3px;margin-bottom:3px">Leadership Experience</div>
                <?php foreach([['CEO','Global Ventures Inc','2018–Present'],['COO','TechGroup Ltd','2012–2018'],['VP Strategy','Consulting Co','2008–2012']] as [$r,$c,$y]): ?>
                <div style="margin-bottom:4px;display:flex;justify-content:space-between"><div><div style="font-weight:bold;font-size:5.5px"><?=$r?>, <?=$c?></div><div style="color:#6b7280;font-size:5px">• Managed P&amp;L of $500M+ revenue</div></div><span style="font-size:4.5px;color:#6366f1;white-space:nowrap"><?=$y?></span></div>
                <?php endforeach; ?>
                <div style="font-size:5.5px;font-weight:bold;color:#312e81;text-transform:uppercase;margin:4px 0 2px">Education</div>
                <div style="font-size:5.5px;font-weight:bold">MBA, Harvard Business School</div>
                <div style="color:#6b7280;font-size:5px">Class of 2000 · Dean's List</div>
              </div>
            </div>
            <div class="tpl-hover-overlay">
              <a href="<?= SITE_URL ?>/candidate/register.php">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template3_glassmorphism.html" target="_blank" class="outline"><i class="fas fa-eye me-1"></i> Preview</a>
            </div>
          </div>
          <div class="tpl-body">
            <div class="tpl-name">Executive Elite</div>
            <div class="tpl-desc">Premium design with indigo accent — crafted for senior executives and leaders.</div>
            <div class="tpl-tags"><span class="tpl-tag">Modern</span><span class="tpl-tag">Popular</span><span class="tpl-tag">Executive</span></div>
            <div class="tpl-actions">
              <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-use">Use Template</a>
              <a href="<?= SITE_URL ?>/templates/template3_glassmorphism.html" target="_blank" class="btn-preview"><i class="fas fa-eye"></i> Preview</a>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- AI FEATURES -->
<section id="ai-features">
  <div class="container">
    <div class="text-center mb-5">
      <div class="sec-label">AI Powered</div>
      <h2 class="sec-title">Smart AI Writing Assistant</h2>
      <p class="sec-desc">Let AI help you write a CV that stands out and gets past ATS filters.</p>
    </div>
    <div class="row g-4">
      <?php
      $ai = [
        ['fas fa-magic','#8b5cf6','Generate Professional Summary','AI writes a compelling professional summary tailored to your industry and experience.'],
        ['fas fa-lightbulb','#f59e0b','Skill Suggestions','Get smart skill recommendations based on your job title and field.'],
        ['fas fa-pen-fancy','#10b981','Improve Bullet Points','Transform weak bullet points into impactful achievement statements.'],
        ['fas fa-spell-check','#3b82f6','Grammar Correction','AI automatically fixes grammar, spelling, and punctuation errors.'],
        ['fas fa-search','#6366f1','ATS Keyword Optimizer','Optimize your CV with the right keywords to pass Applicant Tracking Systems.'],
        ['fas fa-chart-line','#e879f9','Score & Feedback','Get a detailed ATS score with actionable improvement suggestions.'],
      ];
      foreach($ai as [$icon,$color,$title,$desc]):
      ?>
      <div class="col-md-6 col-lg-4">
        <div class="ai-card">
          <div class="d-flex align-items-center gap-3 mb-3">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;font-size:1.1rem;color:<?=$color?>"><?= "<i class='$icon'></i>" ?></div>
            <h5 style="margin:0"><?=$title?></h5>
          </div>
          <p><?=$desc?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FEATURES -->
<section id="features" style="background:rgba(255,255,255,0.01)">
  <div class="container">
    <div class="text-center mb-5">
      <div class="sec-label">Features</div>
      <h2 class="sec-title">Everything You Need</h2>
      <p class="sec-desc">Powerful tools to help you create a professional CV quickly and easily.</p>
    </div>
    <div class="row g-4">
      <?php
      $features = [
        ['fas fa-paint-brush','rgba(99,102,241,0.15)','#6366f1','Easy to Use','Intuitive drag-and-drop editor with real-time preview — no design skills needed.'],
        ['fas fa-robot','rgba(16,185,129,0.15)','#10b981','ATS-Friendly','All templates pass ATS filters. Get past automated screening systems with ease.'],
        ['fas fa-brain','rgba(139,92,246,0.15)','#8b5cf6','AI-Powered Writing','Generate professional summaries, improve bullet points, and optimize keywords.'],
        ['fas fa-file-pdf','rgba(245,158,11,0.15)','#f59e0b','Instant PDF Download','Download your CV as a pixel-perfect PDF in seconds.'],
        ['fas fa-globe','rgba(59,130,246,0.15)','#3b82f6','Multi-language Support','Create CVs in multiple languages to target global opportunities.'],
        ['fas fa-shield-alt','rgba(239,68,68,0.15)','#ef4444','Secure & Private','Your data is encrypted and never shared. Full privacy guaranteed.'],
      ];
      foreach($features as [$icon,$bg,$color,$title,$desc]):
      ?>
      <div class="col-md-6 col-lg-4">
        <div class="feature-card">
          <div class="f-icon" style="background:<?=$bg?>;color:<?=$color?>"><?= "<i class='$icon'></i>" ?></div>
          <h5><?=$title?></h5>
          <p><?=$desc?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section id="how-it-works">
  <div class="container">
    <div class="text-center mb-5">
      <div class="sec-label">Process</div>
      <h2 class="sec-title">Build Your CV in 3 Simple Steps</h2>
    </div>
    <div class="row align-items-start g-0">
      <?php
      $steps = [
        ['fas fa-th-large','Choose Template','Pick from 15+ professional templates designed for every industry and career level.'],
        ['fas fa-edit','Fill Your Details','Enter your information with AI assistance. Get suggestions for summary, skills, and achievements.'],
        ['fas fa-download','Download CV','Download your polished, ATS-ready CV as a PDF instantly.'],
      ];
      foreach($steps as $i=>[$icon,$title,$desc]):
      ?>
      <div class="col-lg-4">
        <div class="step-wrap">
          <div class="step-circle"><?=$i+1?></div>
          <div style="width:52px;height:52px;border-radius:14px;background:rgba(99,102,241,0.1);display:flex;align-items:center;justify-content:center;font-size:1.3rem;color:#6366f1;margin:0 auto 1rem"><?= "<i class='$icon'></i>" ?></div>
          <h5><?=$title?></h5>
          <p><?=$desc?></p>
        </div>
      </div>
      <?php if($i<2): ?>
      <div class="col-lg-auto d-none d-lg-flex align-items-center pt-0" style="padding-top:3rem!important">
        <i class="fas fa-chevron-right" style="color:#334155;font-size:1.2rem"></i>
      </div>
      <?php endif; endforeach; ?>
    </div>
    <div class="text-center mt-3">
      <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-hero-primary"><i class="fas fa-rocket"></i> Start Building Now — It's Free</a>
    </div>
  </div>
</section>

<!-- EXAMPLES -->
<section id="examples" style="background:rgba(255,255,255,0.01)">
  <div class="container">
    <div class="text-center mb-5">
      <div class="sec-label">Examples</div>
      <h2 class="sec-title">CVs Built with Our Platform</h2>
      <p class="sec-desc">See real examples of professional CVs created for different career paths.</p>
    </div>
    <div class="row g-4">
      <?php
      $examples = [
        ['Student','#1e293b','#10b981','Fresh Graduate — Business Administration'],
        ['Developer','#0a1628','#6366f1','Full Stack Developer — 3 Years Experience'],
        ['Business Pro','#1e1b4b','#f59e0b','Senior Marketing Manager — Fortune 500'],
        ['Designer','#1a0a2e','#e879f9','UI/UX Designer — Creative Agency'],
        ['Doctor','#0d1117','#3b82f6','Medical Professional — General Practitioner'],
        ['Engineer','#0f172a','#ef4444','Mechanical Engineer — Automotive Industry'],
      ];
      foreach($examples as [$role,$bg,$color,$desc]):
      ?>
      <div class="col-md-6 col-lg-4">
        <div class="example-card">
          <div class="example-preview" style="background:<?=$bg?>">
            <div style="width:70%;background:#fff;border-radius:4px;box-shadow:0 4px 20px rgba(0,0,0,0.2);padding:1.2rem">
              <div style="height:8px;border-radius:3px;background:<?=$color?>;margin-bottom:0.6rem"></div>
              <?php for($j=0;$j<6;$j++): ?><div style="height:3px;background:#e2e8f0;border-radius:2px;margin-bottom:0.3rem;<?=$j%3===1?'width:65%':($j%3===2?'width:45%':'width:100%')?>"></div><?php endfor; ?>
            </div>
            <div class="example-overlay">
              <a href="<?= SITE_URL ?>/candidate/register.php" style="background:#fff;color:#1e293b;padding:0.6rem 1.4rem;border-radius:8px;font-weight:700;font-size:0.85rem;text-decoration:none">Use This Template</a>
            </div>
          </div>
          <div class="example-body">
            <div class="example-role"><?=$role?></div>
            <div class="example-name" style="font-size:0.875rem"><?=$desc?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PRICING -->
<section id="pricing">
  <div class="container">
    <div class="text-center mb-5">
      <div class="sec-label">Pricing</div>
      <h2 class="sec-title">Simple, Transparent Pricing</h2>
      <p class="sec-desc">Start for free. Upgrade when you need more power.</p>
    </div>
    <div class="row g-4 justify-content-center">
      <div class="col-md-5">
        <div class="price-card">
          <div class="price-name">Free Plan</div>
          <div class="price-num">$0 <span>/ month</span></div>
          <div class="price-period">Forever free. No credit card required.</div>
          <ul class="price-features">
            <?php foreach(['3 ATS-Friendly templates','Basic CV builder','PDF download','Email support','1 active CV'] as $f): ?>
            <li><i class="fas fa-check-circle"></i><?=$f?></li>
            <?php endforeach; ?>
            <?php foreach(['AI writing assistant','Premium templates','Unlimited CVs'] as $f): ?>
            <li class="no"><i class="fas fa-times-circle"></i><?=$f?></li>
            <?php endforeach; ?>
          </ul>
          <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-price-outline">Get Started Free</a>
        </div>
      </div>
      <div class="col-md-5">
        <div class="price-card popular">
          <div class="popular-badge">⚡ Most Popular</div>
          <div class="price-name">Premium Plan</div>
          <div class="price-num">$9 <span>/ month</span></div>
          <div class="price-period">Billed monthly. Cancel anytime.</div>
          <ul class="price-features">
            <?php foreach(['15+ Premium templates','Full AI writing assistant','Unlimited CVs','ATS keyword optimizer','Priority support','Cover letter builder','LinkedIn profile optimizer','Multiple download formats'] as $f): ?>
            <li><i class="fas fa-check-circle"></i><?=$f?></li>
            <?php endforeach; ?>
          </ul>
          <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-price-primary">Start Premium — $9/mo</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section style="background:rgba(255,255,255,0.01)">
  <div class="container">
    <div class="text-center mb-5">
      <div class="sec-label">Reviews</div>
      <h2 class="sec-title">What Our Users Say</h2>
    </div>
    <div class="row g-4">
      <?php
      $testimonials = [
        ['#6366f1','SA','Sara Ahmed','Software Engineer','The AI suggestions completely transformed my CV. I get so many more callbacks now. Highly recommend to every professional.'],
        ['#10b981','MK','Muhammad Khan','Marketing Manager','The ATS optimization feature is a game-changer. My CV started getting responses after using CV Craft. Best investment I made.'],
        ['#f59e0b','FA','Fatima Ali','Fresh Graduate','As a fresh graduate with no work experience, I was struggling. CV Craft helped me highlight my skills perfectly. My CV looks incredibly professional!'],
      ];
      foreach($testimonials as [$color,$initials,$name,$role,$review]):
      ?>
      <div class="col-md-4">
        <div class="testi-card">
          <div class="stars">★★★★★</div>
          <p class="testi-text">"<?=$review?>"</p>
          <div class="testi-author">
            <div class="testi-avatar" style="background:<?=$color?>"><?=$initials?></div>
            <div><div class="testi-name"><?=$name?></div><div class="testi-role"><?=$role?></div></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <!-- Trust Logos Row -->
    <div class="text-center mt-5">
      <p style="font-size:0.82rem;color:#334155;margin-bottom:1.2rem;font-weight:600;text-transform:uppercase;letter-spacing:0.08em">Trusted by professionals at</p>
      <div class="d-flex justify-content-center align-items-center gap-4 flex-wrap">
        <?php foreach(['Google','Microsoft','Amazon','Meta','IBM'] as $co): ?>
        <span style="font-family:'Sora',sans-serif;font-size:1rem;font-weight:800;color:#334155;opacity:0.5"><?=$co?></span>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- PORTALS -->
<section id="portals">
  <div class="container">
    <div class="text-center mb-5">
      <div class="sec-label">Portals</div>
      <h2 class="sec-title">Two Dedicated Portals</h2>
    </div>
    <div class="row g-4">
      <div class="col-lg-6">
        <a class="portal-card portal-admin" href="<?= ADMIN_URL ?>/dashboard.php">
          <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:1rem">
            <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center"><i class="fas fa-user-shield" style="color:#fff"></i></div>
            <h4 style="margin:0">Admin Panel</h4>
          </div>
          <p>Complete control over the platform — manage templates, candidates, and downloads.</p>
          <ul class="portal-list">
            <?php foreach(['Manage CV templates','View all candidates','Download logs & reports','Manage categories','Admin user control'] as $f): ?>
            <li><i class="fas fa-check-circle"></i><?=$f?></li>
            <?php endforeach; ?>
          </ul>
          <span class="portal-link" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff">Open Admin Panel <i class="fas fa-arrow-right ms-1"></i></span>
        </a>
      </div>
      <div class="col-lg-6">
        <a class="portal-card portal-cand" href="<?= CANDIDATE_URL ?>/register.php">
          <div style="display:flex;align-items:center;gap:0.75rem;margin-bottom:1rem">
            <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,#10b981,#059669);display:flex;align-items:center;justify-content:center"><i class="fas fa-user-tie" style="color:#fff"></i></div>
            <h4 style="margin:0">Candidate Portal</h4>
          </div>
          <p>Build your professional CV, download it, and manage your templates — all in one place.</p>
          <ul class="portal-list">
            <?php foreach(['Register & create profile','Build professional CV','Browse template library','Download & share your CV','Save favourite templates'] as $f): ?>
            <li><i class="fas fa-check-circle"></i><?=$f?></li>
            <?php endforeach; ?>
          </ul>
          <span class="portal-link" style="background:linear-gradient(135deg,#10b981,#059669);color:#fff">Get Started Free <i class="fas fa-arrow-right ms-1"></i></span>
        </a>
      </div>
    </div>
  </div>
</section>

<!-- CTA STRIP -->
<section class="cta-strip">
  <div class="container text-center py-2">
    <h2 class="sec-title mb-3">Ready to Build Your Perfect CV?</h2>
    <p style="color:#64748b;max-width:480px;margin:0 auto 2rem;font-size:0.95rem;line-height:1.7">Create your professional CV today. It's free, fast, and ATS-optimized.</p>
    <div class="d-flex gap-3 justify-content-center flex-wrap">
      <a href="<?= SITE_URL ?>/candidate/register.php" class="btn-hero-primary"><i class="fas fa-user-plus"></i> Create Free Account</a>
      <a href="#templates" class="btn-hero-outline"><i class="fas fa-th-large"></i> Browse Templates</a>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4">
        <a class="brand mb-3 d-inline-flex" href="<?= SITE_URL ?>">
          <div class="brand-box me-2"><i class="fas fa-file-alt" style="color:#fff;font-size:0.9rem"></i></div>
          <span class="brand-txt">CV <span>Craft</span></span>
        </a>
        <p class="footer-desc">AI-powered CV builder and hiring platform. Create stunning, ATS-friendly CVs in minutes.</p>
        <div class="footer-social">
          <?php foreach(['fab fa-twitter','fab fa-linkedin-in','fab fa-github','fab fa-instagram'] as $ic): ?>
          <a href="#" class="social-btn"><i class="<?=$ic?>"></i></a>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="col-lg-2 col-md-3 col-6">
        <div class="footer-heading">Product</div>
        <ul class="footer-links">
          <li><a href="#templates">Templates</a></li>
          <li><a href="#features">Features</a></li>
          <li><a href="#pricing">Pricing</a></li>
          <li><a href="#examples">Examples</a></li>
        </ul>
      </div>
      <div class="col-lg-2 col-md-3 col-6">
        <div class="footer-heading">Portals</div>
        <ul class="footer-links">
          <li><a href="<?= ADMIN_URL ?>/dashboard.php">Admin Panel</a></li>
          <li><a href="<?= CANDIDATE_URL ?>/register.php">Candidate Portal</a></li>
          <li><a href="<?= SITE_URL ?>/login.php">Login</a></li>
          <li><a href="<?= SITE_URL ?>/candidate/register.php">Sign Up</a></li>
        </ul>
      </div>
      <div class="col-lg-2 col-md-3 col-6">
        <div class="footer-heading">Company</div>
        <ul class="footer-links">
          <li><a href="#">About Us</a></li>
          <li><a href="#">Contact</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="#">Careers</a></li>
        </ul>
      </div>
      <div class="col-lg-2 col-md-3 col-6">
        <div class="footer-heading">Legal</div>
        <ul class="footer-links">
          <li><a href="#">Privacy Policy</a></li>
          <li><a href="#">Terms of Service</a></li>
          <li><a href="#">Cookie Policy</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom d-flex justify-content-between flex-wrap gap-2">
      <span>&copy; <?= date('Y') ?> CV Craft. All rights reserved.</span>
      <span style="display:flex;gap:0.5rem;flex-wrap:wrap">
        <?php foreach(['PHP 8','MySQL','Bootstrap 5','Claude AI','Chart.js'] as $t): ?>
        <span style="background:rgba(255,255,255,0.04);border:1px solid var(--border);color:#475569;padding:0.18rem 0.55rem;border-radius:5px;font-size:0.75rem"><?=$t?></span>
        <?php endforeach; ?>
      </span>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Navbar scroll
window.addEventListener('scroll',()=>document.getElementById('mainNav').classList.toggle('scrolled',scrollY>50));

// Template filter
function filterTpl(btn, cat) {
    document.querySelectorAll('.tpl-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.tpl-item').forEach(item=>{
        var itemCat = item.dataset.cat || '';
        item.style.display = (cat==='All' || itemCat===cat) ? '' : 'none';
    });
}
</script>
</body>
</html>
