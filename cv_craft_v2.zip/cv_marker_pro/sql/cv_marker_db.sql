-- ============================================================
-- CV Marker Pro - Updated Database Schema v2.0
-- Changes: username column added, first_name/last_name separate
-- ============================================================

CREATE DATABASE IF NOT EXISTS cv_marker_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cv_marker_db;

DROP TABLE IF EXISTS activity_logs;
DROP TABLE IF EXISTS cover_letters;
DROP TABLE IF EXISTS cvs;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS cv_scores;
DROP TABLE IF EXISTS cv_applications;
DROP TABLE IF EXISTS job_positions;
DROP TABLE IF EXISTS employers;
DROP TABLE IF EXISTS candidates;
DROP TABLE IF EXISTS admin_users;
DROP TABLE IF EXISTS system_settings;

-- Admin Users
CREATE TABLE admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('reviewer','admin','super_admin') DEFAULT 'reviewer',
    is_active TINYINT(1) DEFAULT 1,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Employers
CREATE TABLE employers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(150) NOT NULL,
    contact_name VARCHAR(120) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(30) NULL,
    location VARCHAR(120) NULL,
    website VARCHAR(255) NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Candidates (username + first_name + last_name separate)
CREATE TABLE candidates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    first_name VARCHAR(60) NOT NULL,
    last_name VARCHAR(60) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NULL,
    city VARCHAR(60) NULL,
    gender ENUM('male','female','other') NULL,
    date_of_birth DATE NULL,
    application_id VARCHAR(20) UNIQUE,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Job Positions
CREATE TABLE job_positions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    department VARCHAR(100) NULL,
    category VARCHAR(100) NULL,
    location VARCHAR(120) NULL,
    description TEXT NULL,
    required_skills TEXT NULL,
    min_experience INT DEFAULT 0,
    max_experience INT DEFAULT 10,
    education_required ENUM('any','matric','intermediate','bachelors','masters','phd') DEFAULT 'any',
    total_marks INT DEFAULT 100,
    passing_marks INT DEFAULT 50,
    deadline DATE NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_by INT NULL,
    employer_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admin_users(id) ON DELETE SET NULL,
    FOREIGN KEY (employer_id) REFERENCES employers(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- CV Applications
CREATE TABLE cv_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id INT NOT NULL,
    position_id INT NOT NULL,
    cv_file VARCHAR(255) NULL,
    cover_letter TEXT NULL,
    education_level ENUM('matric','intermediate','bachelors','masters','phd') NOT NULL,
    institution VARCHAR(150) NULL,
    cgpa_percentage VARCHAR(20) NULL,
    total_experience INT DEFAULT 0,
    current_employer VARCHAR(100) NULL,
    current_designation VARCHAR(100) NULL,
    skills TEXT NULL,
    certifications TEXT NULL,
    linkedin_url VARCHAR(255) NULL,
    portfolio_url VARCHAR(255) NULL,
    status ENUM('pending','under_review','scored','shortlisted','rejected','hired') DEFAULT 'pending',
    submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_app (candidate_id, position_id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
    FOREIGN KEY (position_id) REFERENCES job_positions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- CV Scores
CREATE TABLE cv_scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL UNIQUE,
    reviewed_by INT NULL,
    ai_education_score DECIMAL(5,2) DEFAULT 0,
    ai_experience_score DECIMAL(5,2) DEFAULT 0,
    ai_skills_score DECIMAL(5,2) DEFAULT 0,
    ai_overall_score DECIMAL(5,2) DEFAULT 0,
    ai_feedback TEXT NULL,
    manual_education_score DECIMAL(5,2) DEFAULT 0,
    manual_experience_score DECIMAL(5,2) DEFAULT 0,
    manual_skills_score DECIMAL(5,2) DEFAULT 0,
    manual_presentation_score DECIMAL(5,2) DEFAULT 0,
    manual_overall_score DECIMAL(5,2) DEFAULT 0,
    manual_comments TEXT NULL,
    final_score DECIMAL(5,2) DEFAULT 0,
    scoring_method ENUM('ai','manual','hybrid') DEFAULT 'ai',
    scored_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES cv_applications(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Notifications
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id INT NULL,
    application_id INT NULL,
    type VARCHAR(50) DEFAULT 'general',
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Activity Logs
CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_type ENUM('admin','candidate') NOT NULL,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    description TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE cvs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id INT NOT NULL,
    title VARCHAR(150) NOT NULL DEFAULT 'Untitled CV',
    template VARCHAR(50) NOT NULL DEFAULT 'clean',
    data_json LONGTEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_candidate (candidate_id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE cover_letters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id INT NOT NULL,
    title VARCHAR(150) NOT NULL DEFAULT 'Cover Letter',
    applicant_name VARCHAR(150) NOT NULL,
    company VARCHAR(150) NOT NULL,
    position VARCHAR(150) NOT NULL,
    template VARCHAR(50) NOT NULL DEFAULT 'formal',
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_candidate (candidate_id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- System Settings
CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NULL,
    description VARCHAR(255) NULL
) ENGINE=InnoDB;

-- Default Admin (password: admin123)
INSERT INTO admin_users (username, email, password, full_name, role) VALUES
('admin', 'admin@cvmarker.com', '$2y$12$I3eHNY6ZG008g3bBdeOmhufg.VyDffBPKk/C6GZTsjSKgZp8qZAOG', 'Administrator', 'super_admin');

-- Sample Employer (password: employer123)
INSERT INTO employers (company_name, contact_name, email, password, phone, location, website) VALUES
('TechBridge Solutions', 'HR Manager', 'employer@cvmarker.com', '$2y$12$Psh7PK4Ng/wseAZWHV3mBOHekNgIDF/iVRldrmCSFNUBI749cX0Ym', '+92-300-0000000', 'Lahore', 'https://example.com');

-- Default Settings
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('site_name','CV Marker Pro','Site name'),
('ai_scoring_enabled','1','Enable AI scoring'),
('max_cv_size_mb','5','Max CV size in MB');

-- Sample Jobs
INSERT INTO job_positions (title, department, category, location, description, required_skills, min_experience, max_experience, education_required, total_marks, passing_marks, deadline, is_active, created_by, employer_id) VALUES
('Senior PHP Developer','IT','Software Development','Lahore','Laravel + MySQL expert needed','PHP,Laravel,MySQL,JavaScript',3,8,'bachelors',100,60,DATE_ADD(NOW(),INTERVAL 30 DAY),1,1,1),
('Data Analyst','Analytics','Data','Remote','Python & SQL expertise required','Python,SQL,Excel,Power BI',2,5,'bachelors',100,55,DATE_ADD(NOW(),INTERVAL 45 DAY),1,1,1),
('Project Manager','Management','Management','Karachi','PMP certified PM for software projects','PMP,Agile,Scrum,Leadership',5,12,'masters',100,65,DATE_ADD(NOW(),INTERVAL 20 DAY),1,1,1);


-- ============================================================
-- Template Download Portal - Additional Tables
-- ============================================================

-- Template Categories
CREATE TABLE IF NOT EXISTS template_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(50) DEFAULT 'fa-file-alt',
    description TEXT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Downloadable Templates
CREATE TABLE IF NOT EXISTS downloadable_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    category_id INT NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    preview_image VARCHAR(255) NULL,
    file_type ENUM('zip','pdf','docx','psd','ai','figma') DEFAULT 'pdf',
    file_size INT DEFAULT 0,
    download_count INT DEFAULT 0,
    is_featured TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    tags VARCHAR(500) NULL,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES template_categories(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Download History
CREATE TABLE IF NOT EXISTS download_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    template_id INT NOT NULL,
    downloaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45) NULL,
    FOREIGN KEY (user_id) REFERENCES candidates(id) ON DELETE CASCADE,
    FOREIGN KEY (template_id) REFERENCES downloadable_templates(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Favorites
CREATE TABLE IF NOT EXISTS favorites (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    template_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_fav (user_id, template_id),
    FOREIGN KEY (user_id) REFERENCES candidates(id) ON DELETE CASCADE,
    FOREIGN KEY (template_id) REFERENCES downloadable_templates(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Default Categories
INSERT INTO template_categories (name, slug, icon, description, sort_order) VALUES
('CV / Resume', 'cv-resume', 'fa-file-alt', 'Professional CV and resume templates', 1),
('Cover Letter', 'cover-letter', 'fa-envelope-open-text', 'Formal cover letter templates', 2),
('Business Card', 'business-card', 'fa-id-card', 'Modern business card designs', 3),
('Portfolio', 'portfolio', 'fa-briefcase', 'Creative portfolio layouts', 4),
('Flyer', 'flyer', 'fa-newspaper', 'Event and business flyer templates', 5),
('Invoice', 'invoice', 'fa-file-invoice', 'Professional invoice templates', 6);

-- Sample Templates
INSERT INTO downloadable_templates (title, description, category_id, file_path, preview_image, file_type, download_count, is_featured, tags) VALUES
('Clean CV Template', 'A clean, minimal CV template that keeps the focus on your experience and skills. Perfect for any job application.', 1, 'templates/sample_cv_clean.pdf', 'previews/cv_clean.jpg', 'pdf', 245, 1, 'clean,minimal,professional,ats-friendly'),
('Professional Corporate CV', 'A structured, traditional CV layout ideal for business, finance, and office roles.', 1, 'templates/sample_cv_corporate.pdf', 'previews/cv_corporate.jpg', 'pdf', 189, 1, 'corporate,traditional,business,formal'),
('Modern CV Template', 'A contemporary CV design with clear structure and subtle visual accents.', 1, 'templates/sample_cv_modern.pdf', 'previews/cv_modern.jpg', 'pdf', 312, 1, 'modern,creative,colorful,design'),
('Creative CV for Makers', 'An expressive CV layout that showcases your personality, creativity, and style.', 1, 'templates/sample_cv_creative.pdf', 'previews/cv_creative.jpg', 'pdf', 156, 1, 'creative,artistic,portfolio,designer'),
('Executive Resume', 'Premium executive resume template for senior management and C-level positions.', 1, 'templates/sample_cv_executive.pdf', 'previews/cv_executive.jpg', 'pdf', 98, 0, 'executive,senior,management,premium'),
('Formal Cover Letter', 'Traditional cover letter format suitable for corporate and government applications.', 2, 'templates/cover_letter_formal.pdf', 'previews/cover_formal.jpg', 'pdf', 134, 1, 'formal,corporate,traditional'),
('Creative Cover Letter', 'Modern cover letter with a fresh layout and design elements.', 2, 'templates/cover_letter_creative.pdf', 'previews/cover_creative.jpg', 'pdf', 87, 0, 'creative,modern,colorful'),
('Minimal Business Card', 'Clean and minimal business card design for professionals.', 3, 'templates/bcard_minimal.zip', 'previews/bcard_minimal.jpg', 'zip', 201, 1, 'minimal,clean,professional'),
('Dark Business Card', 'Elegant dark-themed business card with gold accents.', 3, 'templates/bcard_dark.zip', 'previews/bcard_dark.jpg', 'zip', 167, 0, 'dark,elegant,gold,premium'),
('Portfolio Layout', 'Creative portfolio layout for designers and artists.', 4, 'templates/portfolio_creative.zip', 'previews/portfolio_creative.jpg', 'zip', 76, 0, 'portfolio,creative,designer');

-- Additional system settings for CV Builder
INSERT IGNORE INTO system_settings (setting_key, setting_value, description) VALUES
('site_name', 'CV Marker Pro', 'Name of the website'),
('site_tagline', 'Build Your Professional Resume', 'Site tagline or subtitle'),
('contact_email', 'admin@cvmarker.com', 'Contact/support email'),
('allow_registration', '1', 'Allow new candidate registrations'),
('max_cvs_per_user', '10', 'Maximum CVs a candidate can save'),
('default_template', 'clean', 'Default CV template for new builds'),
('enable_downloads', '1', 'Allow candidates to download CVs as PDF'),
('maintenance_mode', '0', 'Put site in maintenance mode');
