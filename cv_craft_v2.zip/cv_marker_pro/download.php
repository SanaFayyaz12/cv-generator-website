<?php
require_once 'includes/config.php';
if (!isset($_SESSION['candidate_id'])) {
    setFlash('danger', 'Please login to download templates.');
    header('Location: login.php'); exit;
}
$db = getDB();
$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: templates_browse.php'); exit; }

$stmt = $db->prepare("SELECT * FROM downloadable_templates WHERE id=? AND is_active=1");
$stmt->execute([$id]);
$tpl = $stmt->fetch();
if (!$tpl) {
    setFlash('danger', 'Template not found.');
    header('Location: templates_browse.php'); exit;
}

// Log download
$db->prepare("INSERT INTO download_history (user_id, template_id, ip_address) VALUES (?, ?, ?)")
   ->execute([$_SESSION['candidate_id'], $id, $_SERVER['REMOTE_ADDR'] ?? '']);

// Increment counter
$db->prepare("UPDATE downloadable_templates SET download_count = download_count + 1 WHERE id=?")->execute([$id]);

// Serve file
$safeTitle = preg_replace('/[^A-Za-z0-9_-]+/', '_', $tpl['title']);
$filePath = realpath(__DIR__ . '/uploads/' . $tpl['file_path']);
$uploadsRoot = realpath(__DIR__ . '/uploads');
if ($filePath && $uploadsRoot && strpos($filePath, $uploadsRoot) === 0 && file_exists($filePath)) {
    $ext = pathinfo($filePath, PATHINFO_EXTENSION);
    $mimes = ['pdf'=>'application/pdf','zip'=>'application/zip','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document','doc'=>'application/msword'];
    $mime = $mimes[$ext] ?? 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Content-Disposition: attachment; filename="' . $safeTitle . '.' . $ext . '"');
    header('Content-Length: ' . filesize($filePath));
    header('Cache-Control: no-cache');
    readfile($filePath);
    exit;
} else {
    $lines = [
        SITE_NAME,
        $tpl['title'],
        '',
        $tpl['description'] ?: 'Professional downloadable template.',
        '',
        'This starter PDF is generated automatically when the original template asset is not present.',
        'You can replace it by uploading the real file at: uploads/' . $tpl['file_path'],
    ];
    $content = "BT\n/F1 22 Tf\n72 760 Td\n(" . pdfText($lines[0]) . ") Tj\n/F1 16 Tf\n0 -38 Td\n(" . pdfText($lines[1]) . ") Tj\n/F1 11 Tf\n0 -34 Td\n";
    foreach (array_slice($lines, 2) as $line) {
        $content .= "(" . pdfText($line) . ") Tj\n0 -18 Td\n";
    }
    $content .= "ET";
    $pdf = buildSimplePdf($content);
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $safeTitle . '.pdf"');
    header('Content-Length: ' . strlen($pdf));
    header('Cache-Control: no-cache');
    echo $pdf;
    exit;
}

function pdfText($text) {
    return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\(', '\)', ' ', ' '], (string)$text);
}

function buildSimplePdf($stream) {
    $objects = [];
    $objects[] = "<< /Type /Catalog /Pages 2 0 R >>";
    $objects[] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";
    $objects[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>";
    $objects[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
    $objects[] = "<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "\nendstream";
    $pdf = "%PDF-1.4\n";
    $offsets = [0];
    foreach ($objects as $i => $object) {
        $offsets[] = strlen($pdf);
        $pdf .= ($i + 1) . " 0 obj\n" . $object . "\nendobj\n";
    }
    $xref = strlen($pdf);
    $pdf .= "xref\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n";
    for ($i = 1; $i <= count($objects); $i++) {
        $pdf .= str_pad((string)$offsets[$i], 10, '0', STR_PAD_LEFT) . " 00000 n \n";
    }
    $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n" . $xref . "\n%%EOF";
    return $pdf;
}
